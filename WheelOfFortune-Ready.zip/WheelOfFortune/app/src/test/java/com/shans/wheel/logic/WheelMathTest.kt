package com.shans.wheel.logic

import com.shans.wheel.data.Person
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import java.util.Random
import kotlin.math.abs
import org.junit.Test

class WheelMathTest {

    private fun people(n: Int, weights: List<Double>? = null) =
        (0 until n).map { Person(id = "p$it", name = "نفر $it", weight = weights?.get(it) ?: 1.0) }

    @Test
    fun segmentsCoverFullCircle() {
        for (weighted in listOf(false, true)) {
            val segs = WheelMath.segments(people(7, listOf(1.0, 2.0, 3.0, 0.5, 4.0, 1.5, 1.0)), weighted)
            assertEquals(0f, segs.first().start, 1e-4f)
            assertEquals(360f, segs.last().start + segs.last().sweep, 1e-3f)
            for (i in 1 until segs.size) assertEquals(segs[i - 1].start + segs[i - 1].sweep, segs[i].start, 1e-3f)
        }
    }

    @Test
    fun pointerAlwaysLandsInsideWinnerSegment() {
        val rnd = Random(1)
        for (trial in 0 until 5000) {
            val n = 1 + rnd.nextInt(40)
            val weighted = rnd.nextBoolean()
            val ps = people(n, List(n) { 0.1 + rnd.nextDouble() * 20 })
            val segs = WheelMath.segments(ps, weighted)
            val w = WheelMath.pickWinner(ps, weighted, rnd)
            val target = WheelMath.targetAngle(segs[w], rnd)
            val current = rnd.nextFloat() * 3000f - 500f
            val fin = WheelMath.finalRotation(current, target, 3 + rnd.nextInt(10))
            assertTrue(fin > current)
            assertEquals(w, WheelMath.indexUnderPointer(segs, fin))
        }
    }

    @Test
    fun fairModeIsUniform() {
        val rnd = Random(42)
        val ps = people(5)
        val counts = IntArray(5)
        val trials = 100_000
        repeat(trials) { counts[WheelMath.pickWinner(ps, false, rnd)]++ }
        counts.forEach { assertTrue(abs(it - trials / 5.0) < trials * 0.01) }
    }

    @Test
    fun weightedModeIsProportional() {
        val rnd = Random(7)
        val ws = listOf(1.0, 2.0, 3.0, 4.0)
        val ps = people(4, ws)
        val counts = IntArray(4)
        val trials = 200_000
        repeat(trials) { counts[WheelMath.pickWinner(ps, true, rnd)]++ }
        for (i in 0 until 4) {
            val expected = ws[i] / ws.sum()
            assertEquals(expected, counts[i].toDouble() / trials, 0.01)
        }
    }

    @Test
    fun balancedAssignDiffersByAtMostOne() {
        val rnd = Random(3)
        for (n in 1..60) for (t in 1..9) {
            val ids = (0 until n).map { "p$it" }
            val teams = (0 until t).map { "t$it" }
            val res = WheelMath.balancedAssign(ids, teams, emptyMap(), rnd)
            assertEquals(n, res.size)
            assertEquals(ids.toSet(), res.keys)
            val sizes = teams.map { tm -> res.values.count { it == tm } }
            assertTrue(sizes.max() - sizes.min() <= 1)
        }
    }

    @Test
    fun balancedAssignRespectsExistingMembers() {
        val res = WheelMath.balancedAssign(listOf("a", "b", "c", "d"), listOf("x", "y"), mapOf("x" to 2, "y" to 0), Random(1))
        assertEquals(4, res.size)
        // x از قبل ۲ نفر دارد؛ پس هر ۴ نفر جدید نباید همه به x بروند
        assertTrue(res.values.count { it == "y" } >= 2)
    }

    @Test
    fun weightParsing() {
        assertEquals(2.5, parseWeight("۲٫۵")!!, 1e-9)
        assertEquals(3.0, parseWeight(" 3 ")!!, 1e-9)
        assertNull(parseWeight("0"))
        assertNull(parseWeight("-1"))
        assertNull(parseWeight("abc"))
        assertNull(parseWeight("1001"))
        assertNull(parseWeight("NaN"))
        assertNotNull(parseWeight("1000"))
    }

    @Test
    fun colorIndexNeverMatchesNeighbours() {
        for (n in 2..40) for (p in 3..10) {
            val cs = (0 until n).map { WheelMath.colorIndex(it, n, p) }
            for (i in 1 until n) assertTrue(cs[i] != cs[i - 1])
            assertTrue(cs.last() != cs.first())
        }
    }
}
