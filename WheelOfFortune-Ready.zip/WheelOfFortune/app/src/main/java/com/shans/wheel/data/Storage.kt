package com.shans.wheel.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** تبدیل وضعیت برنامه به JSON و برعکس (بدون وابستگی خارجی). */
object Codec {

    fun encode(state: AppState): String {
        val root = JSONObject()
        root.put("version", 1)
        root.put("currentListId", state.currentListId ?: JSONObject.NULL)
        root.put("settings", encodeSettings(state.settings))
        val arr = JSONArray()
        state.lists.forEach { arr.put(encodeList(it)) }
        root.put("lists", arr)
        return root.toString()
    }

    fun decode(text: String): AppState {
        val root = JSONObject(text)
        val arr = root.optJSONArray("lists") ?: JSONArray()
        val lists = (0 until arr.length()).map { decodeList(arr.getJSONObject(it)) }
        val cur = if (root.isNull("currentListId")) null else root.getString("currentListId")
        return AppState(
            lists = lists,
            settings = decodeSettings(root.optJSONObject("settings") ?: JSONObject()),
            currentListId = cur?.takeIf { id -> lists.any { it.id == id } }
        )
    }

    private fun encodeSettings(s: Settings): JSONObject = JSONObject().apply {
        put("theme", s.theme.name)
        put("customColors", JSONArray().also { a -> s.customColors.forEach { a.put(it) } })
        put("bgImagePath", s.bgImagePath ?: JSONObject.NULL)
        put("spinSeconds", s.spinSeconds.toDouble())
        put("speed", s.speed)
        put("pointer", s.pointer.name)
        put("visualEffects", s.visualEffects)
        put("soundOn", s.soundOn)
        put("volume", s.volume.toDouble())
        put("spinPack", s.spinPack)
        put("winPack", s.winPack)
        put("haptics", s.haptics)
    }

    private fun decodeSettings(o: JSONObject): Settings {
        val d = Settings()
        val colors = o.optJSONArray("customColors")?.let { a -> (0 until a.length()).map { a.getInt(it) } } ?: emptyList()
        return Settings(
            theme = runCatching { ThemeId.valueOf(o.optString("theme", d.theme.name)) }.getOrDefault(d.theme),
            customColors = if (colors.size >= 2) colors else emptyList(),
            bgImagePath = if (o.isNull("bgImagePath")) null else o.getString("bgImagePath").takeIf { File(it).exists() },
            spinSeconds = o.optDouble("spinSeconds", d.spinSeconds.toDouble()).toFloat().coerceIn(2f, 15f),
            speed = o.optInt("speed", d.speed).coerceIn(1, 5),
            pointer = runCatching { PointerStyle.valueOf(o.optString("pointer", d.pointer.name)) }.getOrDefault(d.pointer),
            visualEffects = o.optBoolean("visualEffects", d.visualEffects),
            soundOn = o.optBoolean("soundOn", d.soundOn),
            volume = o.optDouble("volume", d.volume.toDouble()).toFloat().coerceIn(0f, 1f),
            spinPack = o.optInt("spinPack", d.spinPack).coerceIn(0, 2),
            winPack = o.optInt("winPack", d.winPack).coerceIn(0, 2),
            haptics = o.optBoolean("haptics", d.haptics)
        )
    }

    private fun encodeList(l: WheelList): JSONObject = JSONObject().apply {
        put("id", l.id)
        put("name", l.name)
        put("weighted", l.weighted)
        put("round", l.round)
        put("createdAt", l.createdAt)
        put("people", JSONArray().also { a ->
            l.people.forEach { p ->
                a.put(JSONObject().apply {
                    put("id", p.id); put("name", p.name); put("weight", p.weight)
                    put("picked", p.picked); put("teamId", p.teamId ?: JSONObject.NULL)
                })
            }
        })
        put("teams", JSONArray().also { a ->
            l.teams.forEach { t -> a.put(JSONObject().apply { put("id", t.id); put("name", t.name) }) }
        })
        put("results", JSONArray().also { a ->
            l.results.forEach { r ->
                a.put(JSONObject().apply {
                    put("id", r.id); put("personId", r.personId); put("personName", r.personName)
                    put("time", r.time); put("round", r.round)
                })
            }
        })
    }

    private fun decodeList(o: JSONObject): WheelList {
        val teamsArr = o.optJSONArray("teams") ?: JSONArray()
        val teams = (0 until teamsArr.length()).map {
            val t = teamsArr.getJSONObject(it); Team(t.getString("id"), t.getString("name"))
        }
        val teamIds = teams.map { it.id }.toSet()
        val pArr = o.optJSONArray("people") ?: JSONArray()
        val people = (0 until pArr.length()).map {
            val p = pArr.getJSONObject(it)
            val w = p.optDouble("weight", 1.0)
            val tid = if (p.isNull("teamId")) null else p.getString("teamId")
            Person(
                id = p.getString("id"),
                name = p.getString("name"),
                weight = if (w.isFinite() && w > 0.0) w else 1.0,
                picked = p.optBoolean("picked", false),
                teamId = tid?.takeIf { id -> id in teamIds }
            )
        }
        val rArr = o.optJSONArray("results") ?: JSONArray()
        val results = (0 until rArr.length()).map {
            val r = rArr.getJSONObject(it)
            ResultEntry(r.getString("id"), r.getString("personId"), r.getString("personName"), r.getLong("time"), r.optInt("round", 1))
        }
        return WheelList(
            id = o.getString("id"),
            name = o.getString("name"),
            people = people,
            teams = teams,
            results = results,
            weighted = o.optBoolean("weighted", false),
            round = o.optInt("round", 1),
            createdAt = o.optLong("createdAt", System.currentTimeMillis())
        )
    }
}

/** ذخیره‌سازی محلی: نوشتن در فایل موقت و سپس جایگزینی، تا فایل هنگام بسته‌شدن ناگهانی خراب نشود. */
class Repository(private val context: Context) {
    private val file get() = File(context.filesDir, "state.json")

    fun load(): AppState {
        val f = file
        if (!f.exists()) return AppState()
        return try {
            Codec.decode(f.readText())
        } catch (e: Exception) {
            // فایل خراب: نسخه‌ای از آن نگه داشته می‌شود و برنامه با وضعیت خالی شروع می‌کند
            f.renameTo(File(context.filesDir, "state.corrupt.json"))
            AppState()
        }
    }

    @Synchronized
    fun save(state: AppState) {
        val tmp = File(context.filesDir, "state.json.tmp")
        tmp.writeText(Codec.encode(state))
        if (!tmp.renameTo(file)) {
            file.delete()
            if (!tmp.renameTo(file)) throw java.io.IOException("rename failed")
        }
    }
}
