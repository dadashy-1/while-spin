package com.shans.wheel.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.platform.LocalLayoutDirection
import com.shans.wheel.data.Settings
import com.shans.wheel.data.ThemeId

data class Palette(
    val bgTop: Color,
    val bgBottom: Color,
    val surface: Color,
    val primary: Color,
    val accent: Color,
    val onBg: Color,
    val rim: Color,
    val dark: Boolean,
    val wheel: List<Color>
)

fun paletteFor(id: ThemeId): Palette = when (id) {
    ThemeId.DARK -> Palette(
        Color(0xFF14121F), Color(0xFF241F3D), Color(0xFF2A2644), Color(0xFF8B7CFF), Color(0xFFFFC857),
        Color(0xFFF2F0FF), Color(0xFFFFC857), true,
        listOf(0xFFEF5350, 0xFFFFA726, 0xFFFFEE58, 0xFF66BB6A, 0xFF26C6DA, 0xFF42A5F5, 0xFF7E57C2, 0xFFEC407A).map { Color(it) }
    )
    ThemeId.LIGHT -> Palette(
        Color(0xFFF7F5FF), Color(0xFFE6E0FF), Color(0xFFFFFFFF), Color(0xFF5B4BDB), Color(0xFFE8890C),
        Color(0xFF1B1A2E), Color(0xFF5B4BDB), false,
        listOf(0xFFFF8A80, 0xFFFFD180, 0xFFFFF59D, 0xFFA5D6A7, 0xFF80DEEA, 0xFF90CAF9, 0xFFB39DDB, 0xFFF48FB1).map { Color(it) }
    )
    ThemeId.NEON -> Palette(
        Color(0xFF05010F), Color(0xFF14002E), Color(0xFF1A0B33), Color(0xFF00F0FF), Color(0xFFFF2BD6),
        Color(0xFFEFFFFF), Color(0xFF00F0FF), true,
        listOf(0xFF00F0FF, 0xFFFF2BD6, 0xFF39FF14, 0xFFFFE600, 0xFF8A2BE2, 0xFFFF6A00, 0xFF00FF9C, 0xFFFF0055).map { Color(it) }
    )
    ThemeId.CONTEST -> Palette(
        Color(0xFF08204A), Color(0xFF0D3B80), Color(0xFF123A78), Color(0xFFFFC107), Color(0xFFFF5252),
        Color(0xFFFFFFFF), Color(0xFFFFC107), true,
        listOf(0xFFD32F2F, 0xFFFFC107, 0xFF1976D2, 0xFF388E3C, 0xFFF57C00, 0xFF7B1FA2, 0xFF0097A7, 0xFFC2185B).map { Color(it) }
    )
}

val LocalPalette = staticCompositionLocalOf { paletteFor(ThemeId.DARK) }

/** رنگ‌های واقعی بخش‌های چرخونه: سفارشی کاربر یا پیش‌فرض تم */
fun wheelColors(s: Settings, p: Palette): List<Color> =
    if (s.customColors.size >= 2) s.customColors.map { Color(it) } else p.wheel

/** رنگ متن خوانا روی یک رنگ زمینه */
fun contrastOn(c: Color): Color = if (c.luminance() > 0.5f) Color(0xFF111111) else Color.White

@Composable
fun AppTheme(id: ThemeId, content: @Composable () -> Unit) {
    val p = paletteFor(id)
    val scheme = if (p.dark) {
        darkColorScheme(
            primary = p.primary, onPrimary = contrastOn(p.primary), secondary = p.accent, onSecondary = contrastOn(p.accent),
            background = p.bgTop, onBackground = p.onBg, surface = p.surface, onSurface = p.onBg,
            surfaceVariant = p.surface, onSurfaceVariant = p.onBg.copy(alpha = 0.75f), tertiary = p.accent
        )
    } else {
        lightColorScheme(
            primary = p.primary, onPrimary = Color.White, secondary = p.accent, onSecondary = Color.White,
            background = p.bgTop, onBackground = p.onBg, surface = p.surface, onSurface = p.onBg,
            surfaceVariant = Color(0xFFEDE9FF), onSurfaceVariant = p.onBg.copy(alpha = 0.75f), tertiary = p.accent
        )
    }
    CompositionLocalProvider(
        LocalPalette provides p,
        LocalLayoutDirection provides LayoutDirection.Rtl   // رابط فارسی، راست‌چین
    ) {
        MaterialTheme(colorScheme = scheme, content = content)
    }
}
