package com.shans.wheel

import android.app.Application
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.SystemClock
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.tween
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.shans.wheel.audio.Haptics
import com.shans.wheel.audio.SoundEngine
import com.shans.wheel.data.AppState
import com.shans.wheel.data.Person
import com.shans.wheel.data.Repository
import com.shans.wheel.data.ResultEntry
import com.shans.wheel.data.Settings
import com.shans.wheel.data.Team
import com.shans.wheel.data.WheelList
import com.shans.wheel.logic.WheelMath
import com.shans.wheel.logic.fa
import com.shans.wheel.logic.parseWeight
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.drop
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.security.SecureRandom

data class WinnerInfo(val personId: String, val name: String, val listId: String)
data class UndoInfo(val undoLabel: String? = null, val redoLabel: String? = null, val undoCount: Int = 0, val redoCount: Int = 0)

enum class DivScope(val label: String) {
    ALL("همه‌ی افراد"), UNASSIGNED("فقط افراد بدون تیم"), PICKED("فقط افراد انتخاب‌شده در چرخونه")
}

data class DivisionRequest(val useExisting: Boolean, val newTeamCount: Int, val scope: DivScope)

data class DivisionProposal(
    val teams: List<Team>,
    val newTeams: List<Team>,
    val assignments: Map<String, String>
)

val SpinEasing = CubicBezierEasing(0.08f, 0.6f, 0.12f, 1f)
const val MAX_UNDO = 50

@OptIn(FlowPreview::class)
class AppViewModel(app: Application) : AndroidViewModel(app) {

    private val repo = Repository(app)
    private val _state = MutableStateFlow(repo.load())
    val state: StateFlow<AppState> = _state.asStateFlow()

    /** زاویه‌ی چرخونه؛ در ViewModel نگه‌داری می‌شود تا با تغییر صفحه/چرخش گوشی، چرخش قطع نشود */
    val rotation = Animatable(0f)

    val sound = SoundEngine()
    private val haptics = Haptics(app)
    private val rnd = SecureRandom()

    val events = MutableSharedFlow<String>(extraBufferCapacity = 16)

    var spinning by mutableStateOf(false); private set
    var winner by mutableStateOf<WinnerInfo?>(null); private set
    var showAllPicked by mutableStateOf(false)
    var proposal by mutableStateOf<DivisionProposal?>(null); private set
    var undoInfo by mutableStateOf(UndoInfo()); private set
    private var lastDivision: DivisionRequest? = null

    private class Hist(val label: String, val snap: WheelList)
    private val undoStacks = HashMap<String, ArrayList<Hist>>()
    private val redoStacks = HashMap<String, ArrayList<Hist>>()

    init {
        sound.preload()
        viewModelScope.launch {
            _state.collect {
                sound.enabled = it.settings.soundOn
                sound.volume = it.settings.volume
            }
        }
        viewModelScope.launch {
            _state.drop(1).debounce(250).collect { s ->
                try {
                    withContext(Dispatchers.IO) { repo.save(s) }
                } catch (e: Exception) {
                    say("ذخیره‌سازی اطلاعات ناموفق بود؛ فضای حافظه‌ی گوشی را بررسی کنید.")
                }
            }
        }
        refreshUndoInfo()
    }

    /** ذخیره‌ی فوری (هنگام خروج از برنامه) */
    fun flush() {
        try { runBlocking(Dispatchers.IO) { repo.save(_state.value) } } catch (_: Exception) {}
    }

    override fun onCleared() {
        sound.stopAll()
        sound.release()
        super.onCleared()
    }

    fun say(msg: String) { events.tryEmit(msg) }

    // ---------- کمکی‌ها ----------

    private fun findList(id: String?): WheelList? = _state.value.lists.firstOrNull { it.id == id }
    fun currentList(): WheelList? = findList(_state.value.currentListId)

    private fun replaceList(l: WheelList) =
        _state.update { s -> s.copy(lists = s.lists.map { if (it.id == l.id) l else it }) }

    private fun nameError(clean: String, others: List<String>, kind: String): String? = when {
        clean.isEmpty() -> "نام $kind نمی‌تواند خالی باشد."
        clean.length > 40 -> "نام $kind نباید بیش از ۴۰ نویسه باشد."
        others.any { it.equals(clean, ignoreCase = true) } -> "«$clean» قبلاً وجود دارد."
        else -> null
    }

    private fun clean(raw: String) = raw.trim().replace(Regex("\\s+"), " ")
    private val weightError = "وزن باید عددی مثبت و حداکثر ۱۰۰۰ باشد."

    // ---------- فهرست‌ها (غیرقابل Undo؛ حذف با تأیید) ----------

    fun createList(raw: String): String? {
        val name = clean(raw)
        nameError(name, _state.value.lists.map { it.name }, "فهرست")?.let { return it }
        val l = WheelList(name = name)
        _state.update { it.copy(lists = it.lists + l, currentListId = l.id) }
        afterListSwitch()
        return null
    }

    fun openList(id: String) {
        if (findList(id) == null) return
        _state.update { it.copy(currentListId = id) }
        afterListSwitch()
    }

    fun closeList() {
        if (spinning) { say("تا پایان چرخش صبر کنید."); return }
        _state.update { it.copy(currentListId = null) }
        afterListSwitch()
    }

    private fun afterListSwitch() {
        winner = null; proposal = null; showAllPicked = false
        viewModelScope.launch { rotation.snapTo(0f) }
        refreshUndoInfo()
    }

    fun renameList(id: String, raw: String): String? {
        val name = clean(raw)
        nameError(name, _state.value.lists.filter { it.id != id }.map { it.name }, "فهرست")?.let { return it }
        _state.update { s -> s.copy(lists = s.lists.map { if (it.id == id) it.copy(name = name) else it }) }
        return null
    }

    fun deleteList(id: String) {
        if (spinning) { say("تا پایان چرخش صبر کنید."); return }
        undoStacks.remove(id); redoStacks.remove(id)
        _state.update { s -> s.copy(lists = s.lists.filter { it.id != id }, currentListId = s.currentListId?.takeIf { it != id }) }
        afterListSwitch()
    }

    // ---------- Undo / Redo ----------

    private fun refreshUndoInfo() {
        val id = _state.value.currentListId
        val u = id?.let { undoStacks[it] }
        val r = id?.let { redoStacks[it] }
        undoInfo = UndoInfo(u?.lastOrNull()?.label, r?.lastOrNull()?.label, u?.size ?: 0, r?.size ?: 0)
    }

    private fun mutate(listId: String, label: String, f: (WheelList) -> WheelList): Boolean {
        if (spinning) { say("تا پایان چرخش صبر کنید."); return false }
        val old = findList(listId) ?: return false
        val new = f(old)
        if (new == old) return false
        val st = undoStacks.getOrPut(listId) { ArrayList() }
        st.add(Hist(label, old))
        if (st.size > MAX_UNDO) st.removeAt(0)
        redoStacks[listId]?.clear()
        replaceList(new)
        refreshUndoInfo()
        return true
    }

    private fun mutateCur(label: String, f: (WheelList) -> WheelList): Boolean {
        val id = _state.value.currentListId ?: return false
        return mutate(id, label, f)
    }

    fun undo() {
        if (spinning) { say("در حال چرخش امکان بازگشت نیست."); return }
        val id = _state.value.currentListId ?: return
        val st = undoStacks[id]
        if (st.isNullOrEmpty()) { say("مرحله‌ای برای بازگشت وجود ندارد."); return }
        val cur = findList(id) ?: return
        val h = st.removeAt(st.lastIndex)
        redoStacks.getOrPut(id) { ArrayList() }.add(Hist(h.label, cur))
        replaceList(h.snap.copy(name = cur.name))
        winner = null; proposal = null
        refreshUndoInfo()
        say("بازگشت: ${h.label}")
    }

    fun redo() {
        if (spinning) { say("در حال چرخش امکان انجام مجدد نیست."); return }
        val id = _state.value.currentListId ?: return
        val st = redoStacks[id]
        if (st.isNullOrEmpty()) { say("مرحله‌ای برای انجام مجدد وجود ندارد."); return }
        val cur = findList(id) ?: return
        val h = st.removeAt(st.lastIndex)
        undoStacks.getOrPut(id) { ArrayList() }.add(Hist(h.label, cur))
        replaceList(h.snap.copy(name = cur.name))
        winner = null; proposal = null
        refreshUndoInfo()
        say("انجام مجدد: ${h.label}")
    }

    // ---------- افراد ----------

    fun addPerson(nameRaw: String, weightRaw: String = "1"): String? {
        val l = currentList() ?: return "فهرستی باز نیست."
        val name = clean(nameRaw)
        nameError(name, l.people.map { it.name }, "فرد")?.let { return it }
        val w = parseWeight(weightRaw) ?: return weightError
        return if (mutate(l.id, "افزودن $name") { it.copy(people = it.people + Person(name = name, weight = w)) }) null
        else "افزودن انجام نشد."
    }

    fun addBulk(text: String): String? {
        val l = currentList() ?: return "فهرستی باز نیست."
        val seen = l.people.map { it.name.lowercase() }.toMutableSet()
        val fresh = ArrayList<Person>()
        var skipped = 0
        text.lines().map { clean(it) }.filter { it.isNotEmpty() }.forEach { n ->
            if (n.length > 40 || !seen.add(n.lowercase())) skipped++ else fresh.add(Person(name = n))
        }
        if (fresh.isEmpty()) return "نام جدیدی برای افزودن پیدا نشد."
        if (!mutate(l.id, "افزودن ${fa(fresh.size)} نفر") { it.copy(people = it.people + fresh) }) return "افزودن انجام نشد."
        say("${fa(fresh.size)} نفر اضافه شد" + if (skipped > 0) " (${fa(skipped)} مورد تکراری/نامعتبر نادیده گرفته شد)" else "")
        return null
    }

    fun editPerson(id: String, nameRaw: String, weightRaw: String): String? {
        val l = currentList() ?: return "فهرستی باز نیست."
        val name = clean(nameRaw)
        nameError(name, l.people.filter { it.id != id }.map { it.name }, "فرد")?.let { return it }
        val w = parseWeight(weightRaw) ?: return weightError
        mutate(l.id, "ویرایش $name") { cur ->
            cur.copy(people = cur.people.map { if (it.id == id) it.copy(name = name, weight = w) else it })
        }
        return null
    }

    fun deletePerson(id: String) {
        val l = currentList() ?: return
        val p = l.people.firstOrNull { it.id == id } ?: return
        mutate(l.id, "حذف ${p.name}") { cur ->
            cur.copy(people = cur.people.filter { it.id != id }, results = cur.results.filter { it.personId != id })
        }
    }

    fun setWeighted(on: Boolean) {
        mutateCur(if (on) "فعال‌سازی وزن‌دهی" else "حالت عادلانه") { it.copy(weighted = on) }
    }

    fun restorePerson(id: String) {
        val l = currentList() ?: return
        val p = l.people.firstOrNull { it.id == id && it.picked } ?: return
        mutate(l.id, "بازگرداندن ${p.name}") { cur ->
            val lastIdx = cur.results.indexOfLast { it.personId == id }
            cur.copy(
                people = cur.people.map { if (it.id == id) it.copy(picked = false) else it },
                results = if (lastIdx >= 0) cur.results.filterIndexed { i, _ -> i != lastIdx } else cur.results
            )
        }
        if (winner?.personId == id) winner = null
    }

    /** دور جدید: همه به چرخونه برمی‌گردند؛ تاریخچه‌ی نتایج حفظ می‌شود */
    fun newRound() {
        if (mutateCur("شروع دور جدید") { cur ->
                cur.copy(people = cur.people.map { it.copy(picked = false) }, round = cur.round + 1)
            }) { winner = null; showAllPicked = false }
    }

    /** پاک‌کردن تاریخچه‌ی نتایج و بازگرداندن همه به چرخونه (با تأیید در UI) */
    fun clearResults() {
        if (mutateCur("پاک‌کردن نتایج") { cur ->
                cur.copy(people = cur.people.map { it.copy(picked = false) }, results = emptyList(), round = 1)
            }) { winner = null; showAllPicked = false }
    }

    // ---------- تیم‌ها ----------

    fun addTeam(raw: String): String? {
        val l = currentList() ?: return "فهرستی باز نیست."
        val name = clean(raw)
        nameError(name, l.teams.map { it.name }, "تیم")?.let { return it }
        mutate(l.id, "ساخت تیم $name") { it.copy(teams = it.teams + Team(name = name)) }
        return null
    }

    fun renameTeam(id: String, raw: String): String? {
        val l = currentList() ?: return "فهرستی باز نیست."
        val name = clean(raw)
        nameError(name, l.teams.filter { it.id != id }.map { it.name }, "تیم")?.let { return it }
        mutate(l.id, "تغییر نام تیم به $name") { cur ->
            cur.copy(teams = cur.teams.map { if (it.id == id) it.copy(name = name) else it })
        }
        return null
    }

    fun deleteTeam(id: String) {
        val l = currentList() ?: return
        val t = l.teams.firstOrNull { it.id == id } ?: return
        mutate(l.id, "حذف تیم ${t.name}") { cur ->
            cur.copy(
                teams = cur.teams.filter { it.id != id },
                people = cur.people.map { if (it.teamId == id) it.copy(teamId = null) else it }
            )
        }
    }

    /** هر فرد فقط در یک تیم است؛ تخصیص جدید جایگزین تیم قبلی می‌شود (teamId = null یعنی بدون تیم) */
    fun assignToTeam(personId: String, teamId: String?) {
        val l = currentList() ?: return
        val p = l.people.firstOrNull { it.id == personId } ?: return
        val t = teamId?.let { id -> l.teams.firstOrNull { it.id == id } }
        if (teamId != null && t == null) return
        val label = if (t != null) "تخصیص ${p.name} به ${t.name}" else "حذف ${p.name} از تیم"
        mutate(l.id, label) { cur ->
            cur.copy(people = cur.people.map { if (it.id == personId) it.copy(teamId = teamId) else it })
        }
    }

    /** ساخت تیم جدید و تخصیص فرد به آن، در یک مرحله‌ی قابل بازگشت */
    fun createTeamAndAssign(personId: String, raw: String): String? {
        val l = currentList() ?: return "فهرستی باز نیست."
        val p = l.people.firstOrNull { it.id == personId } ?: return "فرد پیدا نشد."
        val name = clean(raw)
        nameError(name, l.teams.map { it.name }, "تیم")?.let { return it }
        val t = Team(name = name)
        mutate(l.id, "تخصیص ${p.name} به $name") { cur ->
            cur.copy(teams = cur.teams + t, people = cur.people.map { if (it.id == personId) it.copy(teamId = t.id) else it })
        }
        return null
    }

    // ---------- تقسیم خودکار تیم‌ها ----------

    fun proposeDivision(req: DivisionRequest): String? {
        val l = currentList() ?: return "فهرستی باز نیست."
        val scopePeople = when (req.scope) {
            DivScope.ALL -> l.people
            DivScope.UNASSIGNED -> l.people.filter { it.teamId == null }
            DivScope.PICKED -> l.people.filter { it.picked }
        }
        if (scopePeople.isEmpty()) return "هیچ فردی در محدوده‌ی انتخاب‌شده وجود ندارد."
        val teams: List<Team>
        val newTeams: List<Team>
        if (req.useExisting) {
            if (l.teams.size < 2) return "برای استفاده از تیم‌های موجود، حداقل دو تیم بسازید."
            teams = l.teams; newTeams = emptyList()
        } else {
            val n = req.newTeamCount
            if (n < 2 || n > 50) return "تعداد تیم‌ها باید بین ۲ تا ۵۰ باشد."
            val used = l.teams.map { it.name }.toMutableSet()
            val made = ArrayList<Team>()
            var k = 1
            while (made.size < n) {
                val nm = "تیم ${fa(k++)}"
                if (used.add(nm)) made.add(Team(name = nm))
            }
            teams = made; newTeams = made
        }
        if (scopePeople.size < teams.size) return "تعداد افراد (${fa(scopePeople.size)}) کمتر از تعداد تیم‌هاست (${fa(teams.size)})."
        val scopeIds = scopePeople.map { it.id }.toSet()
        val base = teams.associate { t -> t.id to l.people.count { it.teamId == t.id && it.id !in scopeIds } }
        val assignment = WheelMath.balancedAssign(scopePeople.map { it.id }, teams.map { it.id }, base, rnd)
        lastDivision = req
        proposal = DivisionProposal(teams, newTeams, assignment)
        return null
    }

    fun redivide() { lastDivision?.let { proposeDivision(it) } }
    fun cancelProposal() { proposal = null }

    fun confirmDivision() {
        val pr = proposal ?: return
        if (mutateCur("تقسیم خودکار تیم‌ها") { cur ->
                cur.copy(
                    teams = cur.teams + pr.newTeams,
                    people = cur.people.map { p -> pr.assignments[p.id]?.let { p.copy(teamId = it) } ?: p }
                )
            }) {
            proposal = null
            say("تیم‌ها تقسیم شدند. برای برگشت از دکمه‌ی بازگشت استفاده کنید.")
        }
    }

    // ---------- چرخش ----------

    fun spin() {
        if (spinning) return
        val l = currentList() ?: return
        val active = l.active
        if (l.people.isEmpty()) { say("فهرست خالی است؛ ابتدا چند نفر اضافه کنید."); return }
        if (active.isEmpty()) { showAllPicked = true; return }
        if (active.size == 1) say("فقط یک نفر در چرخونه مانده است.")

        val st = _state.value.settings
        val segs = WheelMath.segments(active, l.weighted)
        val idx = WheelMath.pickWinner(active, l.weighted, rnd)   // برنده پیش از شروع، و دقیقاً مطابق وزن‌ها تعیین می‌شود
        val target = WheelMath.targetAngle(segs[idx], rnd)         // انیمیشن دقیقاً روی بخش همین برنده متوقف می‌شود
        val from = rotation.value
        val to = WheelMath.finalRotation(from, target, 3 + st.speed * 2)
        val person = active[idx]
        val listId = l.id
        val pack = st.spinPack

        spinning = true
        winner = null
        viewModelScope.launch {
            try {
                sound.startDrum(pack)
                var lastIdx = WheelMath.indexUnderPointer(segs, from)
                var lastTick = 0L
                var near = false
                rotation.animateTo(to, tween((st.spinSeconds * 1000).toInt(), easing = SpinEasing)) {
                    val v = value
                    val i = WheelMath.indexUnderPointer(segs, v)
                    if (i != lastIdx) {
                        lastIdx = i
                        val now = SystemClock.uptimeMillis()
                        if (now - lastTick >= 40) { lastTick = now; sound.playTick(pack) }
                    }
                    if (!near && (v - from) / (to - from) > 0.85f) {
                        near = true
                        sound.playNearStop(pack)
                        sound.setDrumLevel(0.45f)
                    }
                }
                sound.stopDrum()
                rotation.snapTo(WheelMath.norm360(to))
                finishSpin(listId, person, st)
            } finally {
                sound.stopDrum()
                spinning = false
            }
        }
    }

    private fun finishSpin(listId: String, p: Person, st: Settings) {
        spinning = false
        mutate(listId, "انتخاب ${p.name}") { cur ->
            cur.copy(
                people = cur.people.map { if (it.id == p.id) it.copy(picked = true) else it },
                results = cur.results + ResultEntry(personId = p.id, personName = p.name, time = System.currentTimeMillis(), round = cur.round)
            )
        }
        winner = WinnerInfo(p.id, p.name, listId)
        sound.playWin(st.winPack)
        sound.playApplause(st.winPack)
        if (st.haptics) haptics.win()
    }

    fun dismissWinner() { winner = null }

    // ---------- تنظیمات ----------

    fun updateSettings(f: (Settings) -> Settings) {
        _state.update { it.copy(settings = f(it.settings)) }
    }

    fun resetSettings() {
        _state.value.settings.bgImagePath?.let { File(it).delete() }
        updateSettings { Settings() }
        say("تنظیمات به حالت پیش‌فرض برگشت.")
    }

    fun previewSounds() {
        val s = _state.value.settings
        sound.playTick(s.spinPack)
        viewModelScope.launch {
            kotlinx.coroutines.delay(250)
            sound.playWin(s.winPack)
        }
    }

    fun setBackground(uri: Uri) {
        viewModelScope.launch {
            val path = withContext(Dispatchers.IO) { importImage(uri) }
            if (path == null) {
                say("خواندن تصویر ممکن نشد.")
            } else {
                val old = _state.value.settings.bgImagePath
                updateSettings { it.copy(bgImagePath = path) }
                old?.let { File(it).delete() }
            }
        }
    }

    fun clearBackground() {
        _state.value.settings.bgImagePath?.let { File(it).delete() }
        updateSettings { it.copy(bgImagePath = null) }
    }

    /** کپی و کوچک‌سازی تصویر در حافظه‌ی داخلی برنامه، تا به مجوز دائمی دسترسی به گالری نیازی نباشد */
    private fun importImage(uri: Uri): String? {
        return try {
            val ctx = getApplication<Application>()
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            while (bounds.outWidth / sample > 1600 || bounds.outHeight / sample > 1600) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            val bmp = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) } ?: return null
            val f = File(ctx.filesDir, "bg_${System.currentTimeMillis()}.jpg")
            FileOutputStream(f).use { bmp.compress(Bitmap.CompressFormat.JPEG, 88, it) }
            bmp.recycle()
            f.absolutePath
        } catch (e: Exception) {
            null
        }
    }
}
