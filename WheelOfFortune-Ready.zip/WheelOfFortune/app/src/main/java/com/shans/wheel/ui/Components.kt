package com.shans.wheel.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp

/** دیالوگ ورود نام؛ onConfirm پیام خطا برمی‌گرداند (null = موفق) و خطا همان‌جا نمایش داده می‌شود */
@Composable
fun NameDialog(
    title: String,
    label: String,
    initial: String = "",
    confirmText: String = "تأیید",
    onDismiss: () -> Unit,
    onConfirm: (String) -> String?
) {
    var text by remember { mutableStateOf(initial) }
    var err by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it; err = null },
                label = { Text(label) },
                singleLine = true,
                isError = err != null,
                supportingText = err?.let { e -> @Composable { Text(e) } }
            )
        },
        confirmButton = {
            TextButton(onClick = {
                val e = onConfirm(text)
                if (e == null) onDismiss() else err = e
            }) { Text(confirmText) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } }
    )
}

@Composable
fun ConfirmDialog(
    title: String,
    text: String,
    confirmText: String = "تأیید",
    onDismiss: () -> Unit,
    onConfirm: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { Text(text) },
        confirmButton = { TextButton(onClick = { onConfirm(); onDismiss() }) { Text(confirmText) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } }
    )
}

@Composable
fun InfoDialog(title: String, text: String, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { Text(text) },
        confirmButton = { TextButton(onClick = onDismiss) { Text("متوجه شدم") } }
    )
}

/** دیالوگ ورود چند نام (هر خط یک نفر) */
@Composable
fun BulkAddDialog(onDismiss: () -> Unit, onConfirm: (String) -> String?) {
    var text by remember { mutableStateOf("") }
    var err by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("افزودن گروهی") },
        text = {
            Column {
                Text("هر خط یک نام. نام‌های تکراری نادیده گرفته می‌شوند.", style = MaterialTheme.typography.bodySmall)
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it; err = null },
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                    minLines = 5, maxLines = 10,
                    isError = err != null,
                    supportingText = err?.let { e -> @Composable { Text(e) } }
                )
            }
        },
        confirmButton = {
            TextButton(onClick = { val e = onConfirm(text); if (e == null) onDismiss() else err = e }) { Text("افزودن") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } }
    )
}

private val PRESET_COLORS = listOf(
    0xFFEF5350, 0xFFEC407A, 0xFFAB47BC, 0xFF7E57C2, 0xFF5C6BC0, 0xFF42A5F5,
    0xFF29B6F6, 0xFF26C6DA, 0xFF26A69A, 0xFF66BB6A, 0xFF9CCC65, 0xFFD4E157,
    0xFFFFEE58, 0xFFFFCA28, 0xFFFFA726, 0xFFFF7043, 0xFF8D6E63, 0xFF78909C,
    0xFFFFFFFF, 0xFFBDBDBD, 0xFF616161, 0xFF212121, 0xFF00F0FF, 0xFFFF2BD6
).map { Color(it) }

@Composable
fun ColorPickerDialog(current: Color, onDismiss: () -> Unit, onPick: (Color) -> Unit) {
    var hex by remember { mutableStateOf("") }
    var err by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("انتخاب رنگ") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                PRESET_COLORS.chunked(6).forEach { row ->
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        row.forEach { c ->
                            Modifier
                            androidx.compose.foundation.layout.Box(
                                Modifier.size(36.dp).background(c, CircleShape)
                                    .border(if (c == current) 3.dp else 1.dp, if (c == current) MaterialTheme.colorScheme.primary else Color.Gray, CircleShape)
                                    .clickable { onPick(c); onDismiss() }
                            )
                        }
                    }
                }
                OutlinedTextField(
                    value = hex,
                    onValueChange = { hex = it; err = null },
                    label = { Text("کد رنگ (مثلاً #FF8800)") },
                    singleLine = true,
                    isError = err != null,
                    supportingText = err?.let { e -> @Composable { Text(e) } },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Ascii)
                )
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val h = hex.trim().removePrefix("#")
                val v = if (h.length == 6) h.toLongOrNull(16) else null
                if (v == null) err = "کد رنگ معتبر نیست (۶ رقم هگز)" else { onPick(Color(0xFF000000 or v)); onDismiss() }
            }) { Text("اعمال کد") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("بستن") } }
    )
}
