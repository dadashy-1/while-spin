package com.shans.wheel.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import java.util.Random
import kotlin.concurrent.thread
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin

/**
 * تمام صداها در خود برنامه تولید (سنتز) می‌شوند؛ هیچ فایل صوتی خارجی، مجوز نشر یا اینترنتی لازم نیست.
 * سه بسته‌ی صوتی: ۰ مسابقه‌ای، ۱ هیجان‌انگیز، ۲ جشن.
 */
class SoundEngine {
    private val sr = 22050

    @Volatile var enabled = true
    @Volatile var volume = 0.8f
    @Volatile private var ready = false

    private class Pack(
        val ticks: Array<AudioTrack>,
        val drum: AudioTrack,
        val drumFrames: Int,
        val near: AudioTrack,
        val win: AudioTrack,
        val applause: AudioTrack
    )

    private val packs = arrayOfNulls<Pack>(3)
    private var tickIdx = 0
    private var activeDrum: AudioTrack? = null

    /** ساخت صداها در یک ریسمان پس‌زمینه تا رابط کاربری معطل نشود */
    fun preload() {
        thread(name = "sound-init", isDaemon = true) {
            try {
                for (p in 0..2) packs[p] = buildPack(p)
                ready = true
            } catch (e: Throwable) {
                ready = false
            }
        }
    }

    private fun get(pack: Int): Pack? = if (enabled && ready) packs[pack.coerceIn(0, 2)] else null

    // ---------- پخش ----------

    private fun gain(t: AudioTrack, g: Float) {
        try { t.setVolume((volume * g).coerceIn(0f, 1f)) } catch (_: Exception) {}
    }

    private fun restart(t: AudioTrack, loopFrames: Int = 0) {
        try {
            t.stop()
            t.reloadStaticData()
            if (loopFrames > 0) t.setLoopPoints(0, loopFrames, -1)
            t.play()
        } catch (_: Exception) {}
    }

    fun playTick(pack: Int) {
        val p = get(pack) ?: return
        tickIdx = (tickIdx + 1) % p.ticks.size
        val t = p.ticks[tickIdx]
        gain(t, 0.7f)
        restart(t)
    }

    fun startDrum(pack: Int) {
        val p = get(pack) ?: return
        activeDrum = p.drum
        gain(p.drum, 0.55f)
        restart(p.drum, p.drumFrames)
    }

    fun setDrumLevel(level: Float) {
        activeDrum?.let { gain(it, 0.55f * level) }
    }

    fun stopDrum() {
        try { activeDrum?.stop() } catch (_: Exception) {}
        activeDrum = null
    }

    /** افکت «نزدیک شدن به توقف» */
    fun playNearStop(pack: Int) {
        val p = get(pack) ?: return
        gain(p.near, 0.8f)
        restart(p.near)
    }

    fun playWin(pack: Int) {
        val p = get(pack) ?: return
        gain(p.win, 1f)
        restart(p.win)
    }

    fun playApplause(pack: Int) {
        val p = get(pack) ?: return
        gain(p.applause, 0.8f)
        restart(p.applause)
    }

    fun stopAll() {
        stopDrum()
        packs.forEach { p ->
            p ?: return@forEach
            try { p.near.stop(); p.win.stop(); p.applause.stop() } catch (_: Exception) {}
        }
    }

    fun release() {
        ready = false
        packs.forEach { p ->
            p ?: return@forEach
            (p.ticks.toList() + listOf(p.drum, p.near, p.win, p.applause)).forEach {
                try { it.release() } catch (_: Exception) {}
            }
        }
    }

    // ---------- سنتز ----------

    private fun makeTrack(data: ShortArray): AudioTrack {
        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_GAME)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()
        val fmt = AudioFormat.Builder()
            .setSampleRate(sr)
            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
            .build()
        val t = AudioTrack(attrs, fmt, data.size * 2, AudioTrack.MODE_STATIC, AudioManager.AUDIO_SESSION_ID_GENERATE)
        t.write(data, 0, data.size)
        return t
    }

    private fun toShorts(f: FloatArray): ShortArray {
        var peak = 0.0001f
        for (x in f) peak = max(peak, abs(x))
        val k = 0.85f / peak
        return ShortArray(f.size) { (f[it] * k * 32767f).toInt().coerceIn(-32767, 32767).toShort() }
    }

    private fun buildPack(p: Int): Pack {
        val tickData = tickData(p)
        val ticks = Array(3) { makeTrack(tickData) }
        val drum = drumData(p)
        return Pack(ticks, makeTrack(drum), drum.size, makeTrack(nearData(p)), makeTrack(winData(p)), makeTrack(applauseData(p)))
    }

    private fun tickData(p: Int): ShortArray {
        val n = (0.06 * sr).toInt()
        val f = FloatArray(n)
        for (i in 0 until n) {
            val t = i.toDouble() / sr
            val v = when (p) {
                0 -> (sin(2 * PI * 900 * t) + 0.4 * sin(2 * PI * 1350 * t)) * exp(-t * 110.0)
                1 -> (if (sin(2 * PI * 1500 * t) >= 0) 0.6 else -0.6) * exp(-t * 95.0)
                else -> (sin(2 * PI * 2093 * t) + 0.5 * sin(2 * PI * 3136 * t)) * exp(-t * 55.0)
            }
            f[i] = v.toFloat()
        }
        return toShorts(f)
    }

    /** رول طبل: ضربه‌های سریع نویز + تُن پایین؛ یک ثانیه، قابل تکرار پیوسته */
    private fun drumData(p: Int): ShortArray {
        val n = sr
        val f = FloatArray(n)
        val intervalMs = intArrayOf(60, 42, 75)[p]
        val pitch = intArrayOf(140, 190, 110)[p]
        val rnd = Random(7L + p)
        var hit = 0
        while (hit * intervalMs < 1000) {
            val start = (hit * intervalMs / 1000.0 * sr).toInt()
            val amp = 0.7 + 0.3 * rnd.nextDouble()
            for (j in 0 until (0.12 * sr).toInt()) {
                val idx = start + j
                if (idx >= n) break
                val t = j.toDouble() / sr
                val noise = (rnd.nextDouble() * 2 - 1) * 0.6 * exp(-t * 45.0)
                val tone = sin(2 * PI * pitch * (1 - 0.5 * t) * t) * exp(-t * 28.0)
                f[idx] += (amp * (noise + tone)).toFloat()
            }
            hit++
        }
        return toShorts(f)
    }

    /** صدای صعودی (riser) هنگام نزدیک‌شدن به توقف */
    private fun nearData(p: Int): ShortArray {
        val dur = 0.9
        val n = (dur * sr).toInt()
        val f = FloatArray(n)
        val f0 = doubleArrayOf(400.0, 500.0, 300.0)[p]
        val f1 = doubleArrayOf(1400.0, 1800.0, 1000.0)[p]
        var phase = 0.0
        for (i in 0 until n) {
            val t = i / sr.toDouble()
            val x = t / dur
            phase += 2 * PI * (f0 + (f1 - f0) * x * x) / sr
            val env = sin(PI * x).pow(0.7) * (0.6 + 0.4 * sin(2 * PI * 14 * t))
            f[i] = (sin(phase) * env).toFloat()
        }
        return toShorts(f)
    }

    private fun addNote(f: FloatArray, freq: Double, startSec: Double, durSec: Double, style: Int) {
        val s = (startSec * sr).toInt()
        val len = (durSec * sr).toInt()
        for (j in 0 until len) {
            val idx = s + j
            if (idx >= f.size) break
            val t = j.toDouble() / sr
            val env = exp(-t * 3.0) * (1 - exp(-t * 200.0))
            val w = when (style) {
                1 -> if (sin(2 * PI * freq * t) >= 0) 0.5 else -0.5
                2 -> sin(2 * PI * freq * t) + 0.3 * sin(4 * PI * freq * t) + 0.15 * sin(6 * PI * freq * t)
                else -> sin(2 * PI * freq * t) + 0.2 * sin(4 * PI * freq * t)
            }
            f[idx] += (w * env).toFloat()
        }
    }

    private fun winData(p: Int): ShortArray {
        val f = FloatArray((2.2 * sr).toInt())
        when (p) {
            0 -> {
                doubleArrayOf(523.25, 659.25, 783.99, 1046.5).forEachIndexed { i, fr -> addNote(f, fr, i * 0.13, 0.5, 0) }
                for (fr in doubleArrayOf(523.25, 659.25, 783.99, 1046.5)) addNote(f, fr, 0.55, 1.4, 0)
            }
            1 -> {
                doubleArrayOf(523.25, 587.33, 659.25, 783.99, 880.0, 1046.5).forEachIndexed { i, fr -> addNote(f, fr, i * 0.09, 0.4, 1) }
                for (fr in doubleArrayOf(783.99, 1046.5, 1318.5)) addNote(f, fr, 0.55, 1.3, 1)
            }
            else -> {
                doubleArrayOf(392.0, 523.25, 659.25, 783.99).forEachIndexed { i, fr -> addNote(f, fr, i * 0.15, 0.6, 2) }
                for (fr in doubleArrayOf(523.25, 659.25, 783.99, 1046.5)) addNote(f, fr, 0.62, 1.5, 2)
            }
        }
        return toShorts(f)
    }

    private fun applauseData(p: Int): ShortArray {
        val dur = 3.0
        val n = (dur * sr).toInt()
        val f = FloatArray(n)
        val rnd = Random(99L + p)
        val claps = intArrayOf(120, 160, 220)[p]
        repeat(claps) {
            val start = (rnd.nextDouble() * (dur - 0.4) * sr).toInt()
            val amp = 0.4 + 0.6 * rnd.nextDouble()
            for (j in 0 until (0.015 * sr).toInt()) {
                val idx = start + j
                if (idx >= n) break
                val t = j.toDouble() / sr
                f[idx] += (amp * (rnd.nextDouble() * 2 - 1) * exp(-t * 220.0)).toFloat()
            }
        }
        for (i in 0 until n) {
            val t = i.toDouble() / sr
            f[i] *= (min(1.0, t / 0.4) * min(1.0, (dur - t) / 0.8)).toFloat()
        }
        return toShorts(f)
    }
}

/** لرزش گوشی هنگام اعلام برنده؛ فقط با مجوز عادی VIBRATE و در صورت پشتیبانی دستگاه */
class Haptics(context: Context) {
    private val vib: Vibrator? = try {
        if (Build.VERSION.SDK_INT >= 31) {
            context.getSystemService(VibratorManager::class.java)?.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        }
    } catch (_: Exception) { null }

    fun win() {
        val v = vib ?: return
        if (!v.hasVibrator()) return
        try {
            if (Build.VERSION.SDK_INT >= 26) {
                v.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 70, 60, 70, 60, 180), -1))
            } else {
                @Suppress("DEPRECATION")
                v.vibrate(longArrayOf(0, 70, 60, 70, 60, 180), -1)
            }
        } catch (_: Exception) {}
    }
}
