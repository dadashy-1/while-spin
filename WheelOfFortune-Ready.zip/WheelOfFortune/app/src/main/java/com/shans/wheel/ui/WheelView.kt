package com.shans.wheel.ui

import android.graphics.Typeface
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.AnimationVector1D
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.min
import com.shans.wheel.data.Person
import com.shans.wheel.data.PointerStyle
import com.shans.wheel.logic.Segment
import com.shans.wheel.logic.WheelMath
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin

private const val RADIUS_FACTOR = 0.86f

/**
 * چرخونه: بخش‌ها یک بار روی یک لایه‌ی گرافیکی کشیده می‌شوند و چرخش فقط با rotationZ همان لایه
 * (GPU) انجام می‌شود؛ بنابراین حتی با ده‌ها نفر انیمیشن روان است و هر فریم بازنقاشی سنگین ندارد.
 */
@Composable
fun WheelView(
    people: List<Person>,
    weighted: Boolean,
    rotation: Animatable<Float, AnimationVector1D>,
    colors: List<Color>,
    pointer: PointerStyle,
    pal: Palette,
    emptyText: String,
    modifier: Modifier = Modifier
) {
    val segs = remember(people, weighted) { WheelMath.segments(people, weighted) }
    val paint = remember {
        android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            textAlign = android.graphics.Paint.Align.RIGHT
            typeface = Typeface.DEFAULT_BOLD
        }
    }
    BoxWithConstraints(modifier, contentAlignment = Alignment.Center) {
        val side = min(maxWidth, maxHeight)
        Box(Modifier.size(side)) {
            Box(Modifier.fillMaxSize().graphicsLayer { rotationZ = rotation.value }) {
                Canvas(Modifier.fillMaxSize()) { drawWheel(people, segs, colors, paint, pal, emptyText) }
            }
            Canvas(Modifier.fillMaxSize()) { drawHubAndPointer(pal, pointer) }
        }
    }
}

private fun DrawScope.drawWheel(
    people: List<Person>, segs: List<Segment>, colors: List<Color>,
    paint: android.graphics.Paint, pal: Palette, emptyText: String
) {
    val cx = size.width / 2f
    val cy = size.height / 2f
    val r = size.minDimension / 2f * RADIUS_FACTOR
    if (people.isEmpty()) {
        drawCircle(Color(0xFF555566), r, Offset(cx, cy))
        drawCircle(pal.rim, r, Offset(cx, cy), style = Stroke(r * 0.045f))
        drawIntoNative { nc ->
            paint.color = Color.White.toArgb()
            paint.textSize = r * 0.09f
            paint.textAlign = android.graphics.Paint.Align.CENTER
            nc.drawText(emptyText, cx, cy + r * 0.3f, paint)
            paint.textAlign = android.graphics.Paint.Align.RIGHT
        }
        return
    }
    val n = people.size
    val topLeft = Offset(cx - r, cy - r)
    val arcSize = Size(2 * r, 2 * r)
    for (sg in segs) {
        val c = colors[WheelMath.colorIndex(sg.index, n, colors.size)]
        drawArc(c, sg.start - 90f, sg.sweep, true, topLeft, arcSize)
    }
    if (n > 1) {
        for (sg in segs) {
            val a = Math.toRadians((sg.start - 90f).toDouble())
            drawLine(
                Color(0x66000000), Offset(cx, cy),
                Offset(cx + r * cos(a).toFloat(), cy + r * sin(a).toFloat()), strokeWidth = max(1f, r * 0.006f)
            )
        }
    }
    drawCircle(pal.rim, r, Offset(cx, cy), style = Stroke(r * 0.045f))

    drawIntoNative { nc ->
        for (sg in segs) {
            val sweepRad = Math.toRadians(sg.sweep.toDouble()).toFloat()
            var ts = minOf(r * 0.12f, sweepRad * r * 0.62f * 0.55f)
            if (n == 1) ts = r * 0.12f
            if (ts < 8f) continue                       // بخش خیلی باریک: فقط رنگ نمایش داده می‌شود
            val bg = colors[WheelMath.colorIndex(sg.index, n, colors.size)]
            paint.color = contrastOn(bg).toArgb()
            paint.textSize = ts
            val maxW = r * 0.78f - r * 0.14f
            val name = people[sg.index].name
            val cnt = paint.breakText(name, true, maxW, null)
            val shown = if (cnt < name.length) name.substring(0, max(1, cnt - 1)) + "…" else name
            nc.save()
            nc.rotate(sg.start + sg.sweep / 2f - 90f, cx, cy)
            nc.drawText(shown, cx + r * 0.93f, cy + ts * 0.35f, paint)
            nc.restore()
        }
    }
}

private inline fun DrawScope.drawIntoNative(block: (android.graphics.Canvas) -> Unit) {
    block(drawContext.canvas.nativeCanvas)
}

private fun DrawScope.drawHubAndPointer(pal: Palette, style: PointerStyle) {
    val cx = size.width / 2f
    val cy = size.height / 2f
    val r = size.minDimension / 2f * RADIUS_FACTOR
    // هاب مرکزی
    drawCircle(pal.surface, r * 0.13f, Offset(cx, cy))
    drawCircle(pal.accent, r * 0.13f, Offset(cx, cy), style = Stroke(r * 0.03f))
    drawCircle(pal.accent, r * 0.04f, Offset(cx, cy))

    // نشانگر در بالا؛ نوک آن به‌سمت پایین و روی لبه‌ی چرخونه است
    val top = cy - r
    val u = size.minDimension * 0.035f
    val path = Path()
    when (style) {
        PointerStyle.TRIANGLE -> {
            path.moveTo(cx - u, top - u * 1.5f); path.lineTo(cx + u, top - u * 1.5f)
            path.lineTo(cx, top + u * 1.2f); path.close()
        }
        PointerStyle.ARROW -> {
            path.moveTo(cx - u * 0.45f, top - u * 2.2f); path.lineTo(cx + u * 0.45f, top - u * 2.2f)
            path.lineTo(cx + u * 0.45f, top - u * 0.6f); path.lineTo(cx + u * 1.1f, top - u * 0.6f)
            path.lineTo(cx, top + u * 1.3f); path.lineTo(cx - u * 1.1f, top - u * 0.6f)
            path.lineTo(cx - u * 0.45f, top - u * 0.6f); path.close()
        }
        PointerStyle.DROP -> {
            path.addOval(Rect(Offset(cx, top - u * 1.1f), u))
            path.moveTo(cx - u * 0.85f, top - u * 0.6f); path.lineTo(cx, top + u * 1.3f)
            path.lineTo(cx + u * 0.85f, top - u * 0.6f); path.close()
        }
        PointerStyle.DIAMOND -> {
            path.moveTo(cx, top - u * 1.9f); path.lineTo(cx + u * 1.1f, top - u * 0.4f)
            path.lineTo(cx, top + u * 1.2f); path.lineTo(cx - u * 1.1f, top - u * 0.4f); path.close()
        }
    }
    drawPath(path, pal.accent)
    drawPath(path, Color.White, style = Stroke(u * 0.2f))
}

// ---------------- کاغذرنگی ----------------

private class Particle(
    val x0: Float, val vx: Float, val vy: Float, val rot0: Float, val vr: Float,
    val w: Float, val h: Float, val color: Color
)

/** باران کاغذرنگی؛ ۹۰ ذره و فقط حدود ۴ ثانیه، سپس حلقه‌ی فریم متوقف می‌شود تا باتری مصرف نشود. */
@Composable
fun Confetti(colors: List<Color>, modifier: Modifier = Modifier, durationMs: Long = 4200L) {
    val density = LocalDensity.current.density
    val parts = remember {
        val rnd = java.util.Random()
        List(90) {
            val fromLeft = it % 2 == 0
            Particle(
                x0 = if (fromLeft) 0.05f else 0.95f,
                vx = (if (fromLeft) 1f else -1f) * (200f + rnd.nextFloat() * 700f),
                vy = -(900f + rnd.nextFloat() * 1100f),
                rot0 = rnd.nextFloat() * 360f,
                vr = (rnd.nextFloat() - 0.5f) * 900f,
                w = 6f + rnd.nextFloat() * 8f,
                h = 10f + rnd.nextFloat() * 10f,
                color = colors[rnd.nextInt(colors.size)]
            )
        }
    }
    var timeMs by remember { mutableLongStateOf(0L) }
    LaunchedEffect(Unit) {
        var start = -1L
        while (true) {
            val now = androidx.compose.runtime.withFrameNanos { it }
            if (start < 0) start = now
            timeMs = (now - start) / 1_000_000L
            if (timeMs > durationMs) break
        }
    }
    Canvas(modifier) {
        val t = timeMs / 1000f
        val g = 1500f * density
        val fade = if (timeMs > durationMs - 700) ((durationMs - timeMs) / 700f).coerceIn(0f, 1f) else 1f
        for (p in parts) {
            val x = p.x0 * size.width + p.vx * density * t
            val y = size.height * 0.95f + p.vy * density * t + 0.5f * g * t * t
            if (y > size.height + 40f) continue
            rotate(p.rot0 + p.vr * t, Offset(x, y)) {
                drawRect(p.color.copy(alpha = fade), Offset(x - p.w * density / 2, y - p.h * density / 2), Size(p.w * density, p.h * density))
            }
        }
    }
}
