package com.shans.wheel.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.shans.wheel.AppViewModel
import com.shans.wheel.WinnerInfo
import com.shans.wheel.data.Settings
import com.shans.wheel.data.Team
import com.shans.wheel.data.WheelList

/** چرخونه با رنگ‌ها و نشانگر تنظیم‌شده؛ در حالت عادی و نمایش بزرگ مشترک است. */
@Composable
fun WheelPanel(vm: AppViewModel, list: WheelList, settings: Settings, modifier: Modifier = Modifier) {
    val pal = LocalPalette.current
    val colors = wheelColors(settings, pal)
    val emptyText = if (list.people.isEmpty()) "افرادی اضافه کنید" else "همه انتخاب شدند"
    WheelView(
        people = list.active,
        weighted = list.weighted,
        rotation = vm.rotation,
        colors = colors,
        pointer = settings.pointer,
        pal = pal,
        emptyText = emptyText,
        modifier = modifier
    )
}

@Composable
fun SpinButton(vm: AppViewModel, big: Boolean = false, modifier: Modifier = Modifier) {
    Button(
        onClick = { vm.spin() },
        enabled = !vm.spinning,
        modifier = modifier.height(if (big) 76.dp else 56.dp),
        colors = ButtonDefaults.buttonColors(containerColor = LocalPalette.current.accent, contentColor = contrastOn(LocalPalette.current.accent))
    ) {
        Text(if (vm.spinning) "در حال چرخش…" else "بچرخون 🎡", fontSize = if (big) 28.sp else 20.sp, fontWeight = FontWeight.Bold)
    }
}

/** اعلام برنده: نام بزرگ، درخشش، کاغذرنگی و دکمه‌های اقدام */
@Composable
fun WinnerOverlay(
    info: WinnerInfo,
    effects: Boolean,
    teams: List<Team>,
    vm: AppViewModel,
    colors: List<Color>
) {
    val pal = LocalPalette.current
    var pickTeam by remember { mutableStateOf(false) }
    val scale = remember { Animatable(0.2f) }
    LaunchedEffect(info.personId) {
        scale.animateTo(1f, spring(dampingRatio = 0.45f, stiffness = Spring.StiffnessLow))
    }
    val glow = rememberInfiniteTransition(label = "glow").animateFloat(
        initialValue = 0.35f, targetValue = 0.8f,
        animationSpec = infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "g"
    )
    Box(
        Modifier.fillMaxSize().background(Color(0xD9000000)).clickable(enabled = false) {},
        contentAlignment = Alignment.Center
    ) {
        if (effects) {
            Box(
                Modifier.fillMaxSize().alpha(glow.value)
                    .background(Brush.radialGradient(listOf(pal.accent.copy(alpha = 0.55f), Color.Transparent)))
            )
            Confetti(colors = colors, modifier = Modifier.fillMaxSize())
        }
        Column(
            Modifier.padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text("🎉 برنده 🎉", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
            Text(
                info.name,
                color = pal.accent,
                fontSize = if (info.name.length > 14) 40.sp else 58.sp,
                fontWeight = FontWeight.Black,
                textAlign = TextAlign.Center,
                maxLines = 3,
                modifier = Modifier.graphicsLayer { scaleX = scale.value; scaleY = scale.value }
            )
            Spacer(Modifier.height(10.dp))
            Button(onClick = { pickTeam = true }, modifier = Modifier.fillMaxWidth()) { Text("تخصیص به تیم") }
            Button(onClick = { vm.dismissWinner() }, modifier = Modifier.fillMaxWidth()) { Text("ادامه چرخش") }
            OutlinedButton(onClick = { vm.restorePerson(info.personId) }, modifier = Modifier.fillMaxWidth()) {
                Text("بازگرداندن به چرخونه", color = Color.White)
            }
        }
    }
    if (pickTeam) {
        TeamPickDialog(
            teams = teams,
            onDismiss = { pickTeam = false },
            onPick = { vm.assignToTeam(info.personId, it); vm.dismissWinner() },
            onCreate = { name ->
                val e = vm.createTeamAndAssign(info.personId, name)
                if (e == null) vm.dismissWinner()
                e
            }
        )
    }
}

@Composable
fun TeamPickDialog(
    teams: List<Team>,
    onDismiss: () -> Unit,
    onPick: (String) -> Unit,
    onCreate: (String) -> String?
) {
    var newName by remember { mutableStateOf("") }
    var err by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("تخصیص به کدام تیم؟") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                if (teams.isEmpty()) Text("هنوز تیمی نساخته‌اید. یک تیم جدید بسازید:")
                LazyColumn(Modifier.height(if (teams.size > 4) 220.dp else (teams.size * 52 + 4).dp)) {
                    items(teams, key = { it.id }) { t ->
                        TextButton(onClick = { onPick(t.id); onDismiss() }, modifier = Modifier.fillMaxWidth()) { Text(t.name) }
                    }
                }
                OutlinedTextField(
                    value = newName,
                    onValueChange = { newName = it; err = null },
                    label = { Text("تیم جدید") },
                    singleLine = true,
                    isError = err != null,
                    supportingText = err?.let { e -> @Composable { Text(e) } }
                )
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val e = onCreate(newName)
                if (e == null) onDismiss() else err = e
            }) { Text("ساخت و تخصیص") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } }
    )
}
