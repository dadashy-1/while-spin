package com.shans.wheel

import android.graphics.BitmapFactory
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.ui.unit.dp
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.shans.wheel.ui.AppTheme
import com.shans.wheel.ui.ListScreen
import com.shans.wheel.ui.ListsScreen
import com.shans.wheel.ui.LocalPalette
import com.shans.wheel.ui.SettingsScreen
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    private val vm: AppViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val state by vm.state.collectAsStateWithLifecycle()
            AppTheme(state.settings.theme) { AppRoot(vm) }
        }
    }

    /** ذخیره‌ی فوری هنگام رفتن به پس‌زمینه تا با بستن اجباری برنامه چیزی از دست نرود */
    override fun onStop() {
        vm.flush()
        super.onStop()
    }
}

@Composable
private fun AppRoot(vm: AppViewModel) {
    val state by vm.state.collectAsStateWithLifecycle()
    val pal = LocalPalette.current
    val snack = remember { SnackbarHostState() }
    var showSettings by rememberSaveable { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        vm.events.collect { msg ->
            snack.currentSnackbarData?.dismiss()
            snack.showSnackbar(msg)
        }
    }

    val bg by produceState<ImageBitmap?>(null, state.settings.bgImagePath) {
        val path = state.settings.bgImagePath
        value = if (path == null) null else withContext(Dispatchers.IO) {
            try { BitmapFactory.decodeFile(path)?.asImageBitmap() } catch (e: Throwable) { null }
        }
    }

    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(pal.bgTop, pal.bgBottom)))) {
        bg?.let {
            Image(it, null, Modifier.fillMaxSize().alpha(0.35f), contentScale = ContentScale.Crop)
        }
        val current = state.lists.firstOrNull { it.id == state.currentListId }
        BackHandler(enabled = showSettings) { showSettings = false }
        when {
            showSettings -> SettingsScreen(vm, state.settings) { showSettings = false }
            current == null -> ListsScreen(vm, state) { showSettings = true }
            else -> ListScreen(vm, current, state.settings) { showSettings = true }
        }
        SnackbarHost(snack, Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 84.dp))
    }
}
