package com.shans.wheel.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.shans.wheel.AppViewModel
import com.shans.wheel.data.PointerStyle
import com.shans.wheel.data.SOUND_PACKS
import com.shans.wheel.data.Settings
import com.shans.wheel.data.ThemeId
import com.shans.wheel.logic.fa
import com.shans.wheel.logic.faDigits
import java.util.Locale

@Composable
private fun Section(title: String, content: @Composable () -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            content()
        }
    }
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f))
        Switch(checked, onChange)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(vm: AppViewModel, s: Settings, onBack: () -> Unit) {
    val pal = LocalPalette.current
    var pickIndex by remember { mutableStateOf<Int?>(null) }
    var confirmReset by remember { mutableStateOf(false) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) vm.setBackground(uri)
    }
    val current = wheelColors(s, pal)

    Scaffold(
        containerColor = Color.Transparent,
        topBar = {
            TopAppBar(
                title = { Text("تنظیمات", fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent),
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "بازگشت") } }
            )
        }
    ) { pad ->
        LazyColumn(Modifier.padding(pad).padding(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                Section("ظاهر") {
                    Text("تم")
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        ThemeId.values().forEach { t ->
                            FilterChip(selected = s.theme == t, onClick = {
                                // با تغییر تم، رنگ‌های سفارشی کنار گذاشته می‌شوند تا خوانایی حفظ شود
                                vm.updateSettings { it.copy(theme = t, customColors = emptyList()) }
                            }, label = { Text(t.label) })
                        }
                    }
                    Text("رنگ بخش‌های چرخونه (برای تغییر، روی رنگ بزنید)")
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        current.forEachIndexed { i, c ->
                            Box(
                                Modifier.size(38.dp).clip(CircleShape).background(c)
                                    .border(2.dp, Color.White.copy(alpha = 0.8f), CircleShape)
                                    .clickable { pickIndex = i }
                            )
                        }
                    }
                    if (s.customColors.isNotEmpty()) {
                        TextButton(onClick = { vm.updateSettings { it.copy(customColors = emptyList()) } }) { Text("بازگرداندن رنگ‌های تم") }
                    }
                    Text("سبک نشانگر")
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        PointerStyle.values().forEach { p ->
                            FilterChip(selected = s.pointer == p, onClick = { vm.updateSettings { it.copy(pointer = p) } }, label = { Text(p.label) })
                        }
                    }
                    Text("تصویر پس‌زمینه")
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { picker.launch("image/*") }) { Text("انتخاب از گالری") }
                        if (s.bgImagePath != null) OutlinedButton(onClick = { vm.clearBackground() }) { Text("حذف تصویر") }
                    }
                    SwitchRow("جلوه‌های بصری (کاغذرنگی و درخشش)", s.visualEffects) { v -> vm.updateSettings { it.copy(visualEffects = v) } }
                }
            }
            item {
                Section("چرخش") {
                    Text("مدت چرخش: ${faDigits(String.format(Locale.US, "%.0f", s.spinSeconds))} ثانیه")
                    Slider(value = s.spinSeconds, onValueChange = { v -> vm.updateSettings { it.copy(spinSeconds = Math.round(v).toFloat()) } }, valueRange = 3f..12f, steps = 8)
                    Text("سرعت (تعداد دورها): ${fa(s.speed)} از ${fa(5)}")
                    Slider(value = s.speed.toFloat(), onValueChange = { v -> vm.updateSettings { it.copy(speed = Math.round(v)) } }, valueRange = 1f..5f, steps = 3)
                }
            }
            item {
                Section("صدا و لرزش") {
                    SwitchRow("صداها", s.soundOn) { v -> vm.updateSettings { it.copy(soundOn = v) } }
                    Text("بلندی صدا")
                    Slider(value = s.volume, onValueChange = { v -> vm.updateSettings { it.copy(volume = v) } }, valueRange = 0f..1f)
                    Text("صدای چرخش (طبل و تیک)")
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        SOUND_PACKS.forEachIndexed { i, n ->
                            FilterChip(selected = s.spinPack == i, onClick = { vm.updateSettings { it.copy(spinPack = i) } }, label = { Text(n) })
                        }
                    }
                    Text("صدای اعلام برنده")
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        SOUND_PACKS.forEachIndexed { i, n ->
                            FilterChip(selected = s.winPack == i, onClick = { vm.updateSettings { it.copy(winPack = i) } }, label = { Text(n) })
                        }
                    }
                    OutlinedButton(onClick = { vm.previewSounds() }) { Text("🔊 پخش نمونه") }
                    SwitchRow("لرزش هنگام اعلام برنده", s.haptics) { v -> vm.updateSettings { it.copy(haptics = v) } }
                }
            }
            item {
                Section("بازنشانی") {
                    Text("همه‌ی تنظیمات ظاهری و صوتی به حالت پیش‌فرض برمی‌گردد. فهرست‌ها و افراد تغییر نمی‌کنند.", fontSize = 13.sp)
                    OutlinedButton(onClick = { confirmReset = true }) { Text("بازگرداندن به پیش‌فرض") }
                }
            }
            item {
                Section("منابع صدا و تصویر") {
                    Text("همه‌ی صداها داخل خود برنامه سنتز می‌شوند و فایل صوتی خارجی ندارند. تصاویر و نمادها از خود برنامه‌اند؛ تصویر پس‌زمینه را شما انتخاب می‌کنید.", fontSize = 13.sp)
                }
            }
            item { Box(Modifier.padding(24.dp)) }
        }
    }

    pickIndex?.let { idx ->
        ColorPickerDialog(current = current[idx], onDismiss = { pickIndex = null }) { c ->
            val list = current.map { it.toArgb() }.toMutableList()
            list[idx] = c.toArgb()
            vm.updateSettings { it.copy(customColors = list) }
        }
    }
    if (confirmReset) ConfirmDialog(
        "بازنشانی تنظیمات؟", "همه‌ی تنظیمات به حالت پیش‌فرض برمی‌گردد.", "بازنشانی",
        onDismiss = { confirmReset = false }, onConfirm = { vm.resetSettings() }
    )
}
