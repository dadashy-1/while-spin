package com.shans.wheel.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.shans.wheel.AppViewModel
import com.shans.wheel.DivScope
import com.shans.wheel.DivisionRequest
import com.shans.wheel.data.Person
import com.shans.wheel.data.Settings
import com.shans.wheel.data.WheelList
import com.shans.wheel.logic.fa
import com.shans.wheel.logic.formatPercent
import com.shans.wheel.logic.formatWeight
import com.shans.wheel.logic.normalizeDigits
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// ===================== چرخونه =====================

@Composable
fun WheelTab(vm: AppViewModel, list: WheelList, settings: Settings, goResults: () -> Unit) {
    val pal = LocalPalette.current
    Column(Modifier.fillMaxSize().padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Card(
            colors = CardDefaults.cardColors(containerColor = if (list.weighted) pal.accent.copy(alpha = 0.25f) else pal.primary.copy(alpha = 0.2f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(Modifier.padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(
                    if (list.weighted) "⚖️ حالت وزن‌دهی" else "🎲 حالت عادلانه (شانس برابر)",
                    fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f)
                )
                Text("${fa(list.active.size)} از ${fa(list.people.size)} نفر در چرخونه", fontSize = 13.sp)
            }
        }
        Box(Modifier.weight(1f).fillMaxWidth().padding(vertical = 6.dp), contentAlignment = Alignment.Center) {
            WheelPanel(vm, list, settings, Modifier.fillMaxSize())
        }
        SpinButton(vm, modifier = Modifier.fillMaxWidth())
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            TextButton(onClick = goResults) { Text("انتخاب‌شده‌ها (${fa(list.people.count { it.picked })})") }
            TextButton(onClick = { vm.newRound() }, enabled = !vm.spinning && list.people.any { it.picked }) { Text("دور جدید") }
        }
    }
}

// ===================== افراد =====================

@Composable
fun PeopleTab(vm: AppViewModel, list: WheelList) {
    val pal = LocalPalette.current
    var name by remember { mutableStateOf("") }
    var weight by remember { mutableStateOf("1") }
    var err by remember { mutableStateOf<String?>(null) }
    var editing by remember { mutableStateOf<Person?>(null) }
    var bulk by remember { mutableStateOf(false) }
    var deleting by remember { mutableStateOf<Person?>(null) }
    val activeSum = list.active.sumOf { it.weight }

    fun add() {
        val e = vm.addPerson(name, weight)
        if (e == null) { name = ""; err = null } else err = e
    }

    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Card(
            colors = CardDefaults.cardColors(containerColor = if (list.weighted) pal.accent.copy(alpha = 0.25f) else pal.primary.copy(alpha = 0.2f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(if (list.weighted) "حالت وزن‌دهی فعال است" else "حالت عادلانه: شانس همه برابر است", fontWeight = FontWeight.Bold)
                    Text(
                        if (list.weighted) "وزن بیشتر = احتمال بیشتر؛ اندازه‌ی بخش هر نفر روی چرخونه هم متناسب با وزنش است."
                        else "برای دادن شانس بیشتر به بعضی افراد، وزن‌دهی را روشن کنید.",
                        fontSize = 12.sp
                    )
                }
                Switch(checked = list.weighted, onCheckedChange = { vm.setWeighted(it) })
            }
        }
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                value = name, onValueChange = { name = it; err = null },
                label = { Text("نام فرد") }, singleLine = true, isError = err != null,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                keyboardActions = KeyboardActions(onDone = { add() }),
                modifier = Modifier.weight(1f)
            )
            if (list.weighted) {
                OutlinedTextField(
                    value = weight, onValueChange = { weight = it; err = null },
                    label = { Text("وزن") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier.width(84.dp)
                )
            }
            FilledIconButton(onClick = { add() }, modifier = Modifier.padding(top = 6.dp)) { Icon(Icons.Default.Add, "افزودن") }
        }
        err?.let { Text(it, color = MaterialTheme.colorScheme.error, fontSize = 12.sp) }
        TextButton(onClick = { bulk = true }) { Text("افزودن گروهی (هر خط یک نام)") }

        if (list.people.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("هنوز کسی اضافه نشده است.\nنام اولین نفر را بنویسید.", textAlign = androidx.compose.ui.text.style.TextAlign.Center)
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                items(list.people, key = { it.id }) { p ->
                    Card(Modifier.fillMaxWidth()) {
                        Row(Modifier.padding(start = 12.dp, top = 6.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(p.name, fontWeight = FontWeight.Bold)
                                val sub = buildList {
                                    if (p.picked) add("انتخاب‌شده")
                                    if (list.weighted) {
                                        add("وزن ${formatWeight(p.weight)}")
                                        if (!p.picked && activeSum > 0) add("احتمال ${formatPercent(p.weight / activeSum * 100)}")
                                    }
                                    list.teams.firstOrNull { it.id == p.teamId }?.let { add("تیم ${it.name}") }
                                }.joinToString(" • ")
                                if (sub.isNotEmpty()) Text(sub, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            IconButton(onClick = { editing = p }) { Icon(Icons.Default.Edit, "ویرایش") }
                            IconButton(onClick = { deleting = p }) { Icon(Icons.Default.Delete, "حذف") }
                        }
                    }
                }
            }
        }
    }

    editing?.let { p ->
        EditPersonDialog(p, list.weighted, onDismiss = { editing = null }) { n, w -> vm.editPerson(p.id, n, w) }
    }
    if (bulk) BulkAddDialog(onDismiss = { bulk = false }, onConfirm = { vm.addBulk(it) })
    deleting?.let { p ->
        ConfirmDialog("حذف «${p.name}»؟", "این فرد از فهرست حذف می‌شود (با دکمه‌ی بازگشت قابل برگشت است).", "حذف",
            onDismiss = { deleting = null }, onConfirm = { vm.deletePerson(p.id) })
    }
}

@Composable
private fun EditPersonDialog(p: Person, weighted: Boolean, onDismiss: () -> Unit, onConfirm: (String, String) -> String?) {
    var name by remember { mutableStateOf(p.name) }
    var weight by remember { mutableStateOf(formatWeightPlain(p.weight)) }
    var err by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("ویرایش فرد") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it; err = null }, label = { Text("نام") }, singleLine = true, isError = err != null)
                if (weighted) OutlinedTextField(
                    weight, { weight = it; err = null }, label = { Text("وزن (۰٫۰۱ تا ۱۰۰۰)") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
                )
                err?.let { Text(it, color = MaterialTheme.colorScheme.error, fontSize = 12.sp) }
            }
        },
        confirmButton = {
            TextButton(onClick = { val e = onConfirm(name, weight); if (e == null) onDismiss() else err = e }) { Text("ذخیره") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } }
    )
}

private fun formatWeightPlain(w: Double): String = if (w == Math.floor(w)) w.toInt().toString() else w.toString()

// ===================== تیم‌ها =====================

@Composable
fun TeamsTab(vm: AppViewModel, list: WheelList) {
    var newTeam by remember { mutableStateOf("") }
    var err by remember { mutableStateOf<String?>(null) }
    var renaming by remember { mutableStateOf<String?>(null) }
    var deleting by remember { mutableStateOf<String?>(null) }
    var divide by remember { mutableStateOf(false) }

    fun add() { val e = vm.addTeam(newTeam); if (e == null) { newTeam = ""; err = null } else err = e }

    LazyColumn(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.Top) {
                OutlinedTextField(
                    newTeam, { newTeam = it; err = null }, label = { Text("نام تیم جدید") }, singleLine = true, isError = err != null,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done), keyboardActions = KeyboardActions(onDone = { add() }),
                    modifier = Modifier.weight(1f)
                )
                FilledIconButton(onClick = { add() }, modifier = Modifier.padding(top = 6.dp)) { Icon(Icons.Default.Add, "افزودن تیم") }
            }
            err?.let { Text(it, color = MaterialTheme.colorScheme.error, fontSize = 12.sp) }
            Button(onClick = { divide = true }, modifier = Modifier.fillMaxWidth().padding(top = 6.dp), enabled = list.people.isNotEmpty()) {
                Text("🔀 تقسیم خودکار تیم‌ها")
            }
        }
        val unassigned = list.people.filter { it.teamId == null }
        item {
            TeamCard("بدون تیم", unassigned, list, vm, null, null, null)
        }
        items(list.teams, key = { it.id }) { t ->
            TeamCard(t.name, list.people.filter { it.teamId == t.id }, list, vm, t.id, { renaming = t.id }, { deleting = t.id })
        }
        if (list.teams.isEmpty()) item { Text("هنوز تیمی ساخته نشده است.", fontSize = 13.sp) }
    }

    renaming?.let { id ->
        val t = list.teams.firstOrNull { it.id == id }
        if (t != null) NameDialog("تغییر نام تیم", "نام تیم", t.name, "ذخیره", { renaming = null }) { vm.renameTeam(id, it) }
    }
    deleting?.let { id ->
        val t = list.teams.firstOrNull { it.id == id }
        if (t != null) ConfirmDialog("حذف تیم «${t.name}»؟", "اعضای این تیم بدون تیم می‌شوند (با بازگشت قابل برگشت است).", "حذف",
            onDismiss = { deleting = null }, onConfirm = { vm.deleteTeam(id) })
    }
    if (divide) DivideDialog(vm, list, onDismiss = { divide = false })
    vm.proposal?.let { ProposalDialog(vm, list) }
}

@Composable
private fun TeamCard(
    title: String, members: List<Person>, list: WheelList, vm: AppViewModel,
    teamId: String?, onRename: (() -> Unit)?, onDelete: (() -> Unit)?
) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("$title (${fa(members.size)} نفر)", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                if (onRename != null) IconButton(onClick = onRename) { Icon(Icons.Default.Edit, "تغییر نام") }
                if (onDelete != null) IconButton(onClick = onDelete) { Icon(Icons.Default.Delete, "حذف تیم") }
            }
            if (members.isEmpty()) Text("—", fontSize = 12.sp)
            members.forEach { p ->
                var menu by remember { mutableStateOf(false) }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(p.name + if (p.picked) "  ✔" else "", modifier = Modifier.weight(1f))
                    Box {
                        TextButton(onClick = { menu = true }) { Text(if (teamId == null) "تخصیص" else "انتقال") }
                        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                            list.teams.filter { it.id != teamId }.forEach { t ->
                                DropdownMenuItem(text = { Text(t.name) }, onClick = { menu = false; vm.assignToTeam(p.id, t.id) })
                            }
                            if (teamId != null) DropdownMenuItem(text = { Text("بدون تیم") }, onClick = { menu = false; vm.assignToTeam(p.id, null) })
                            if (list.teams.none { it.id != teamId } && teamId == null) {
                                DropdownMenuItem(text = { Text("ابتدا یک تیم بسازید") }, onClick = { menu = false })
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun DivideDialog(vm: AppViewModel, list: WheelList, onDismiss: () -> Unit) {
    var useExisting by remember { mutableStateOf(list.teams.size >= 2) }
    var count by remember { mutableStateOf("2") }
    var scope by remember { mutableStateOf(DivScope.ALL) }
    var err by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("تقسیم خودکار تیم‌ها") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("تعداد تیم‌ها", fontWeight = FontWeight.Bold)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(selected = useExisting, onClick = { useExisting = true })
                    Text("استفاده از تیم‌های ساخته‌شده (${fa(list.teams.size)})")
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(selected = !useExisting, onClick = { useExisting = false })
                    Text("ساخت تیم‌های جدید")
                    if (!useExisting) {
                        OutlinedTextField(
                            count, { count = it; err = null }, singleLine = true, modifier = Modifier.width(80.dp).padding(start = 8.dp),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                        )
                    }
                }
                Spacer(Modifier.height(6.dp))
                Text("چه کسانی تقسیم شوند؟", fontWeight = FontWeight.Bold)
                DivScope.values().forEach { s ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = scope == s, onClick = { scope = s })
                        Text(s.label)
                    }
                }
                Text("تقسیم مستقل از وزن چرخونه است و تا پیش از تأیید، چیزی تغییر نمی‌کند.", fontSize = 12.sp)
                err?.let { Text(it, color = MaterialTheme.colorScheme.error, fontSize = 12.sp) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val n = normalizeDigits(count).trim().toIntOrNull() ?: 0
                val e = vm.proposeDivision(DivisionRequest(useExisting, n, scope))
                if (e == null) onDismiss() else err = e
            }) { Text("پیش‌نمایش") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } }
    )
}

@Composable
private fun ProposalDialog(vm: AppViewModel, list: WheelList) {
    val pr = vm.proposal ?: return
    val byId = list.people.associateBy { it.id }
    AlertDialog(
        onDismissRequest = { vm.cancelProposal() },
        title = { Text("پیش‌نمایش تقسیم") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                pr.teams.forEach { t ->
                    val ids = pr.assignments.filterValues { it == t.id }.keys
                    val existing = list.people.filter { it.teamId == t.id && it.id !in pr.assignments.keys }
                    val names = (ids.mapNotNull { byId[it]?.name } + existing.map { it.name })
                    Card {
                        Column(Modifier.padding(10.dp)) {
                            Text("${t.name} (${fa(names.size)} نفر)", fontWeight = FontWeight.Bold)
                            Text(if (names.isEmpty()) "—" else names.joinToString("، "), fontSize = 13.sp)
                        }
                    }
                }
                Text("با «تأیید» اعضای فعلی افراد این محدوده جایگزین می‌شوند؛ با دکمه‌ی بازگشت می‌توانید برگردید.", fontSize = 12.sp)
            }
        },
        confirmButton = { TextButton(onClick = { vm.confirmDivision() }) { Text("تأیید") } },
        dismissButton = {
            Row {
                TextButton(onClick = { vm.redivide() }) { Text("تقسیم مجدد") }
                TextButton(onClick = { vm.cancelProposal() }) { Text("انصراف") }
            }
        }
    )
}

// ===================== نتایج =====================

@Composable
fun ResultsTab(vm: AppViewModel, list: WheelList) {
    var confirmClear by remember { mutableStateOf(false) }
    val byId = list.people.associateBy { it.id }
    val fmt = remember { SimpleDateFormat("HH:mm", Locale.getDefault()) }
    LazyColumn(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("دور ${fa(list.round)} • ${fa(list.people.count { it.picked })} نفر انتخاب‌شده از ${fa(list.people.size)}", fontWeight = FontWeight.Bold)
                    if (list.people.isNotEmpty() && list.active.isEmpty()) Text("🎊 همه‌ی افراد انتخاب شدند.")
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { vm.newRound() }, enabled = list.people.any { it.picked }) { Text("دور جدید (بازگرداندن همه)") }
                        OutlinedButton(onClick = { confirmClear = true }, enabled = list.results.isNotEmpty()) { Text("پاک‌کردن نتایج") }
                    }
                }
            }
        }
        if (list.results.isEmpty()) item { Text("هنوز نتیجه‌ای ثبت نشده است.") }
        items(list.results.asReversed(), key = { it.id }) { r ->
            val p = byId[r.personId]
            Card(Modifier.fillMaxWidth()) {
                Row(Modifier.padding(start = 12.dp, top = 4.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(r.personName, fontWeight = FontWeight.Bold)
                        val team = list.teams.firstOrNull { it.id == p?.teamId }?.name
                        Text("دور ${fa(r.round)} • ${com.shans.wheel.logic.faDigits(fmt.format(Date(r.time)))}" + (team?.let { " • تیم $it" } ?: ""), fontSize = 12.sp)
                    }
                    if (p?.picked == true) TextButton(onClick = { vm.restorePerson(p.id) }) { Text("بازگردان") }
                }
            }
        }
    }
    if (confirmClear) ConfirmDialog(
        "پاک‌کردن همه‌ی نتایج؟", "تاریخچه‌ی نتایج پاک می‌شود و همه‌ی افراد به چرخونه برمی‌گردند. (با دکمه‌ی بازگشت قابل برگشت است)",
        "پاک‌کردن", onDismiss = { confirmClear = false }, onConfirm = { vm.clearResults() }
    )
}
