package com.shans.wheel.data

import java.util.UUID

fun newId(): String = UUID.randomUUID().toString()

/** یک نفر در فهرست. picked = از چرخونه خارج شده (انتخاب شده) ولی همچنان در فهرست هست. */
data class Person(
    val id: String = newId(),
    val name: String,
    val weight: Double = 1.0,
    val picked: Boolean = false,
    val teamId: String? = null
)

data class Team(val id: String = newId(), val name: String)

data class ResultEntry(
    val id: String = newId(),
    val personId: String,
    val personName: String,
    val time: Long,
    val round: Int
)

/** یک فهرست مستقل: افراد، تیم‌ها، نتایج و حالت وزن‌دهی مخصوص خودش را دارد. */
data class WheelList(
    val id: String = newId(),
    val name: String,
    val people: List<Person> = emptyList(),
    val teams: List<Team> = emptyList(),
    val results: List<ResultEntry> = emptyList(),
    val weighted: Boolean = false,
    val round: Int = 1,
    val createdAt: Long = System.currentTimeMillis()
) {
    val active: List<Person> get() = people.filter { !it.picked }
}

enum class ThemeId(val label: String) {
    DARK("تیره"), LIGHT("روشن"), NEON("نئونی"), CONTEST("مسابقه‌ای")
}

enum class PointerStyle(val label: String) {
    TRIANGLE("مثلث"), ARROW("پیکان"), DROP("قطره"), DIAMOND("لوزی")
}

val SOUND_PACKS = listOf("مسابقه‌ای", "هیجان‌انگیز", "جشن")

data class Settings(
    val theme: ThemeId = ThemeId.DARK,
    /** رنگ‌های سفارشی بخش‌ها (ARGB). خالی = رنگ‌های پیش‌فرض تم */
    val customColors: List<Int> = emptyList(),
    val bgImagePath: String? = null,
    val spinSeconds: Float = 6f,
    val speed: Int = 3,
    val pointer: PointerStyle = PointerStyle.TRIANGLE,
    val visualEffects: Boolean = true,
    val soundOn: Boolean = true,
    val volume: Float = 0.8f,
    val spinPack: Int = 0,
    val winPack: Int = 2,
    val haptics: Boolean = true
)

data class AppState(
    val lists: List<WheelList> = emptyList(),
    val settings: Settings = Settings(),
    val currentListId: String? = null
)
