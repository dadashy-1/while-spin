package com.shans.wheel.logic

import com.shans.wheel.data.Person
import java.util.Locale
import java.util.Random

/** بخش یک نفر روی چرخونه. زاویه‌ها بر حسب درجه و ساعت‌گرد، از بالای چرخونه (محل نشانگر) هستند. */
data class Segment(val index: Int, val personId: String, val start: Float, val sweep: Float)

object WheelMath {

    /**
     * ساخت بخش‌های چرخونه. در حالت عادلانه همه بخش‌ها هم‌اندازه‌اند؛
     * در حالت وزن‌دهی اندازه‌ی هر بخش متناسب با وزن است. بنابراین احتمال فرود روی هر بخش
     * با سهم دیداری آن برابر است و ظاهر چرخونه همیشه با سیستم انتخاب هماهنگ می‌ماند.
     */
    fun segments(people: List<Person>, weighted: Boolean): List<Segment> {
        if (people.isEmpty()) return emptyList()
        val w = people.map { if (weighted) it.weight else 1.0 }
        val total = w.sum()
        var acc = 0.0
        return people.mapIndexed { i, p ->
            val s = acc / total * 360.0
            acc += w[i]
            val e = if (i == people.lastIndex) 360.0 else acc / total * 360.0
            Segment(i, p.id, s.toFloat(), (e - s).toFloat())
        }
    }

    /** انتخاب برنده با Random امن؛ احتمال هر نفر = وزن او / مجموع وزن‌ها (در حالت عادلانه همه ۱). */
    fun pickWinner(people: List<Person>, weighted: Boolean, rnd: Random): Int {
        require(people.isNotEmpty())
        if (!weighted) return rnd.nextInt(people.size)
        val total = people.sumOf { it.weight }
        val r = rnd.nextDouble() * total
        var acc = 0.0
        for ((i, p) in people.withIndex()) {
            acc += p.weight
            if (r < acc) return i
        }
        return people.lastIndex
    }

    /** نقطه‌ی توقف دقیقاً داخل بخش برنده (با فاصله از مرز دو بخش تا نتیجه مبهم نباشد). */
    fun targetAngle(seg: Segment, rnd: Random): Float {
        val margin = minOf(seg.sweep * 0.15f, 2.5f)
        val lo = seg.start + margin
        val hi = seg.start + seg.sweep - margin
        return if (hi <= lo) seg.start + seg.sweep / 2f else lo + rnd.nextFloat() * (hi - lo)
    }

    fun norm360(a: Float): Float {
        val r = a % 360f
        return if (r < 0f) r + 360f else r
    }

    /**
     * زاویه‌ی نهایی چرخش (ساعت‌گرد). وقتی چرخونه R درجه بچرخد، نقطه‌ای که زیر نشانگر
     * قرار می‌گیرد زاویه‌ی norm(-R) در دستگاه مختصات چرخونه است؛ پس باید R ≡ -target باشد.
     */
    fun finalRotation(current: Float, target: Float, extraTurns: Int): Float {
        val delta = norm360(-target - current)
        return current + extraTurns * 360f + delta
    }

    /** اندیس بخشی که اکنون زیر نشانگر است */
    fun indexUnderPointer(segs: List<Segment>, rotation: Float): Int {
        if (segs.isEmpty()) return -1
        val a = norm360(-rotation)
        for (s in segs) if (a >= s.start && a < s.start + s.sweep) return s.index
        return segs.lastIndex
    }

    /** انتخاب رنگ بخش‌ها؛ بخش آخر هم‌رنگ بخش اول نمی‌شود. */
    fun colorIndex(i: Int, n: Int, paletteSize: Int): Int {
        if (paletteSize <= 0) return 0
        var c = i % paletteSize
        if (paletteSize >= 3 && n > 1 && i == n - 1 && c == 0) c = 1
        return c
    }

    /**
     * توزیع تصادفی و متوازن افراد بین تیم‌ها (مستقل از وزن چرخونه).
     * ابتدا افراد با الگوریتم Fisher–Yates بُر می‌خورند؛ سپس هر نفر به تیمی با کمترین تعداد فعلی می‌رود
     * (در تساوی، تصادفی). اگر تیم‌ها از قبل عضو بیرون از محدوده داشته باشند، همان‌ها هم لحاظ می‌شوند.
     * @return نگاشت شناسه‌ی فرد به شناسه‌ی تیم
     */
    fun balancedAssign(
        personIds: List<String>,
        teamIds: List<String>,
        baseCounts: Map<String, Int>,
        rnd: Random
    ): Map<String, String> {
        require(teamIds.isNotEmpty())
        val shuffled = personIds.toMutableList()
        for (i in shuffled.lastIndex downTo 1) {
            val j = rnd.nextInt(i + 1)
            val t = shuffled[i]; shuffled[i] = shuffled[j]; shuffled[j] = t
        }
        val counts = HashMap<String, Int>()
        teamIds.forEach { counts[it] = baseCounts[it] ?: 0 }
        val out = LinkedHashMap<String, String>()
        for (p in shuffled) {
            val min = teamIds.minOf { counts.getValue(it) }
            val cands = teamIds.filter { counts.getValue(it) == min }
            val t = cands[rnd.nextInt(cands.size)]
            out[p] = t
            counts[t] = counts.getValue(t) + 1
        }
        return out
    }
}

// ---------- ابزارهای متن و عدد ----------

const val MAX_WEIGHT = 1000.0

fun faDigits(s: String): String = buildString {
    for (c in s) append(if (c in '0'..'9') '۰' + (c - '0') else c)
}

fun fa(n: Int): String = faDigits(n.toString())

/** تبدیل ارقام فارسی/عربی و جداکننده‌ی اعشار فارسی به شکل استاندارد */
fun normalizeDigits(s: String): String = buildString {
    for (c in s) {
        append(
            when (c) {
                in '۰'..'۹' -> '0' + (c - '۰')
                in '٠'..'٩' -> '0' + (c - '٠')
                '٫', ',', '،' -> '.'
                else -> c
            }
        )
    }
}

/** وزن معتبر: عدد متناهی، مثبت و حداکثر ۱۰۰۰ */
fun parseWeight(raw: String): Double? {
    val v = normalizeDigits(raw.trim()).toDoubleOrNull() ?: return null
    return if (v.isFinite() && v > 0.0 && v <= MAX_WEIGHT) v else null
}

fun formatWeight(w: Double): String =
    if (w == Math.floor(w)) fa(w.toInt())
    else faDigits(String.format(Locale.US, "%.2f", w).trimEnd('0').trimEnd('.'))

fun formatPercent(p: Double): String = faDigits(String.format(Locale.US, "%.1f", p)) + "٪"
