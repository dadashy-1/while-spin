package com.shans.wheel.ui

import android.app.Activity
import android.content.pm.ActivityInfo
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.shans.wheel.AppViewModel
import com.shans.wheel.data.AppState
import com.shans.wheel.data.Settings
import com.shans.wheel.data.WheelList
import com.shans.wheel.logic.fa

// ===================== فهرست‌ها =====================

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ListsScreen(vm: AppViewModel, state: AppState, openSettings: () -> Unit) {
    var creating by remember { mutableStateOf(false) }
    var renaming by remember { mutableStateOf<WheelList?>(null) }
    var deleting by remember { mutableStateOf<WheelList?>(null) }
    Scaffold(
        containerColor = Color.Transparent,
        topBar = {
            TopAppBar(
                title = { Text("چرخونه شانس 🎡", fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent),
                actions = { IconButton(onClick = openSettings) { Icon(Icons.Default.Settings, "تنظیمات") } }
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = { creating = true }) { Icon(Icons.Default.Add, "فهرست جدید") }
        }
    ) { pad ->
        if (state.lists.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(pad).padding(24.dp), contentAlignment = Alignment.Center) {
                Text(
                    "هنوز فهرستی ندارید.\nبا دکمه‌ی + یک فهرست بسازید (مثلاً «کلاس ۱۰» یا «مسابقه جمعه»).",
                    textAlign = TextAlign.Center
                )
            }
        } else {
            LazyColumn(Modifier.padding(pad).padding(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(state.lists, key = { it.id }) { l ->
                    Card(Modifier.fillMaxWidth().clickable { vm.openList(l.id) }) {
                        Row(Modifier.padding(start = 14.dp, top = 8.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(l.name, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                                Text(
                                    "${fa(l.people.size)} نفر • ${fa(l.teams.size)} تیم • ${fa(l.people.count { it.picked })} انتخاب‌شده",
                                    fontSize = 12.sp
                                )
                            }
                            IconButton(onClick = { renaming = l }) { Icon(Icons.Default.Edit, "تغییر نام") }
                            IconButton(onClick = { deleting = l }) { Icon(Icons.Default.Delete, "حذف") }
                        }
                    }
                }
                item { androidx.compose.foundation.layout.Spacer(Modifier.padding(40.dp)) }
            }
        }
    }
    if (creating) NameDialog("فهرست جدید", "نام فهرست", confirmText = "ساخت", onDismiss = { creating = false }) { vm.createList(it) }
    renaming?.let { l -> NameDialog("تغییر نام فهرست", "نام فهرست", l.name, "ذخیره", { renaming = null }) { vm.renameList(l.id, it) } }
    deleting?.let { l ->
        ConfirmDialog(
            "حذف فهرست «${l.name}»؟",
            "همه‌ی افراد، تیم‌ها و نتایج این فهرست برای همیشه پاک می‌شوند و قابل بازگشت نیست.",
            "حذف فهرست", onDismiss = { deleting = null }, onConfirm = { vm.deleteList(l.id) }
        )
    }
}

// ===================== صفحه‌ی یک فهرست =====================

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ListScreen(vm: AppViewModel, list: WheelList, settings: Settings, openSettings: () -> Unit) {
    val pal = LocalPalette.current
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var showcase by rememberSaveable { mutableStateOf(false) }
    var info by remember { mutableStateOf(false) }
    val u = vm.undoInfo

    BackHandler {
        when {
            showcase -> showcase = false
            vm.spinning -> vm.say("تا پایان چرخش صبر کنید.")
            else -> vm.closeList()
        }
    }

    Box(Modifier.fillMaxSize()) {
        if (showcase) {
            ShowcaseMode(vm, list, settings, onExit = { showcase = false })
        } else {
            Scaffold(
                containerColor = Color.Transparent,
                topBar = {
                    TopAppBar(
                        title = { Text(list.name, maxLines = 1, fontWeight = FontWeight.Bold) },
                        colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent),
                        navigationIcon = {
                            IconButton(onClick = { if (vm.spinning) vm.say("تا پایان چرخش صبر کنید.") else vm.closeList() }) {
                                Icon(Icons.AutoMirrored.Filled.ArrowBack, "بازگشت به فهرست‌ها")
                            }
                        },
                        actions = {
                            TextButton(onClick = { vm.undo() }, enabled = u.undoCount > 0 && !vm.spinning) { Text("↶ بازگشت") }
                            TextButton(onClick = { vm.redo() }, enabled = u.redoCount > 0 && !vm.spinning) { Text("↷") }
                            TextButton(onClick = { info = true }) { Text("ℹ️") }
                            TextButton(onClick = { showcase = true }) { Text("⛶ نمایش بزرگ") }
                            IconButton(onClick = openSettings) { Icon(Icons.Default.Settings, "تنظیمات") }
                        }
                    )
                },
                bottomBar = {
                    NavigationBar(containerColor = pal.surface.copy(alpha = 0.92f)) {
                        listOf("🎡" to "چرخونه", "👥" to "افراد", "🏆" to "تیم‌ها", "📜" to "نتایج").forEachIndexed { i, (emo, label) ->
                            NavigationBarItem(
                                selected = tab == i, onClick = { tab = i },
                                icon = { Text(emo, fontSize = 20.sp) }, label = { Text(label) }
                            )
                        }
                    }
                }
            ) { pad ->
                Box(Modifier.padding(pad).fillMaxSize()) {
                    when (tab) {
                        0 -> WheelTab(vm, list, settings, goResults = { tab = 3 })
                        1 -> PeopleTab(vm, list)
                        2 -> TeamsTab(vm, list)
                        else -> ResultsTab(vm, list)
                    }
                }
            }
        }

        val w = vm.winner
        if (w != null && w.listId == list.id) {
            WinnerOverlay(w, settings.visualEffects, list.teams, vm, wheelColors(settings, pal))
        }
    }

    if (info) InfoDialog(
        "درباره‌ی بازگشت به مرحله‌ی قبل",
        "• تا ${fa(com.shans.wheel.MAX_UNDO)} عملیات آخر هر فهرست قابل بازگشت است (انتخاب، حذف، تخصیص تیم، انتقال، تقسیم خودکار و …).\n" +
            "• تاریخچه‌ی بازگشت با بستن برنامه پاک می‌شود، ولی خود اطلاعات حفظ می‌شود.\n" +
            "• حذف کامل یک فهرست قابل بازگشت نیست و پیش از اجرا تأیید می‌خواهد.\n" +
            "• هنگام چرخش، بازگشت غیرفعال است.\n" +
            (if (u.undoLabel != null) "\nآخرین عملیات: ${u.undoLabel}" else ""),
        onDismiss = { info = false }
    )

    if (vm.showAllPicked) {
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { vm.showAllPicked = false },
            title = { Text("همه انتخاب شدند 🎊") },
            text = { Text("هیچ‌کس در چرخونه نمانده است. می‌توانید دور جدید را شروع کنید تا همه برگردند.") },
            confirmButton = { TextButton(onClick = { vm.newRound() }) { Text("شروع دور جدید") } },
            dismissButton = { TextButton(onClick = { vm.showAllPicked = false }) { Text("بستن") } }
        )
    }
}

// ===================== حالت نمایش بزرگ =====================

@Composable
fun ShowcaseMode(vm: AppViewModel, list: WheelList, settings: Settings, onExit: () -> Unit) {
    val activity = LocalContext.current as? Activity
    val view = LocalView.current
    var landscape by remember { mutableStateOf(false) }

    DisposableEffect(Unit) {
        val window = activity?.window
        val ctrl = window?.let { WindowCompat.getInsetsController(it, it.decorView) }
        ctrl?.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        ctrl?.hide(WindowInsetsCompat.Type.systemBars())
        view.keepScreenOn = true
        onDispose {
            ctrl?.show(WindowInsetsCompat.Type.systemBars())
            view.keepScreenOn = false
            activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
    }

    BoxWithConstraints(Modifier.fillMaxSize().padding(8.dp)) {
        val wide = maxWidth > maxHeight
        val controls: @Composable () -> Unit = {
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                SpinButton(vm, big = true, modifier = Modifier.fillMaxWidth())
                Text("${fa(list.active.size)} نفر در چرخونه", fontSize = 18.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    TextButton(onClick = { vm.undo() }, enabled = vm.undoInfo.undoCount > 0 && !vm.spinning) { Text("↶ بازگشت") }
                    TextButton(onClick = {
                        landscape = !landscape
                        activity?.requestedOrientation =
                            if (landscape) ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE else ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
                    }) { Text("⟳ چرخاندن صفحه") }
                    TextButton(onClick = onExit, enabled = !vm.spinning) { Text("✕ خروج") }
                }
            }
        }
        if (wide) {
            Row(Modifier.fillMaxSize(), verticalAlignment = Alignment.CenterVertically) {
                WheelPanel(vm, list, settings, Modifier.weight(1f).fillMaxSize())
                Box(Modifier.width(260.dp).padding(8.dp)) { controls() }
            }
        } else {
            Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
                WheelPanel(vm, list, settings, Modifier.weight(1f).fillMaxWidth())
                controls()
            }
        }
    }
}
